#include <windows.h>
#include <GL/glut.h>
#include<math.h>>

# define PI           3.14159265358979323846


GLfloat f = 0.0f;
GLfloat position = 0.0f;
GLfloat speed = 0.1f;
GLfloat position1 = 0.0f;
GLfloat speed1 = 0.05f;


void update(int value) {

    if(position >2.0)
        position = -1.0f;

    position += speed;

	glutPostRedisplay();


	glutTimerFunc(150, update, 0);
}

void update1 (int value) {

    if(position1 <-1.0)
        position1 = 1.0f;

    position1 -= speed1;

	glutPostRedisplay();


	glutTimerFunc(200, update1, 0);
}




void Idle()
{
    glutPostRedisplay();
}



void night()
{
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT);

    ///Water///
	glBegin(GL_QUADS);
	glColor3ub(0, 40, 77);
    glVertex2f(-1.0f, 1.0f);
    glVertex2f(-1.0f, 0.3f);
    glVertex2f(1.0f,0.3f);
    glVertex2f(1.0f, 1.0f);
    glEnd();

     ///Night Sky///
	glBegin(GL_QUADS);
	glColor3ub(0,0,0);
    glVertex2f(-1.0f, 1.0f);
    glVertex2f(-1.0f, 0.5f);
    glVertex2f(1.0f,0.5f);
    glVertex2f(1.0f, 1.0f);
    glEnd();

    ///BOAT///
    glPushMatrix();
    glTranslatef(position1,0.0f, 0.0f);
    glBegin(GL_QUADS);
	glColor3ub(0,0,0);
    glVertex2f(0.3f,0.4f);
    glVertex2f(0.4f, 0.35f);
    glVertex2f(0.6f,0.35f);
    glVertex2f(0.7f,0.4f);
    glEnd();

    ///BOATSTAND///
    glLineWidth(2.5);
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(0.62f, 0.32f);
	glVertex2f(0.62f, 0.48f);
    glEnd();
    glPopMatrix();

    ///GRASS///
    glBegin(GL_QUADS);
    glColor3ub(0, 26, 0);
    glVertex2f(-1.0f, -1.0f);
    glVertex2f(1.0f, -1.0f);
    glVertex2f(1.0f,0.3f);
    glVertex2f(-1.0f, 0.3f);
    glEnd();

    /*///BIRD///
    glPushMatrix();
    glTranslatef(position,position, 0.0f);
    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(0.3f,0.4f);
    glVertex2f(0.35f, 0.35f);
    glVertex2f(0.4f,0.4f);
    glVertex2f(0.35f,0.38f);

    glEnd();
    glPopMatrix();*/


     ///TREE///
    glBegin(GL_POLYGON);
    glColor3ub(0, 26, 0);
    glVertex3f(0.2f, 0.90f, 0.0f);
    glVertex3f(0.1f, 0.80f, 0.0f);
    glVertex3f(0.1f, 0.70f, 0.0f);
    glVertex3f(0.2f,0.60f, 0.0f);
    glVertex3f(0.3f, 0.7f, 0.0f);
    glVertex3f(0.3f, 0.8f, 0.0f);
    glEnd();

    ///TREE///
    glLineWidth(7.5);
	glBegin(GL_LINES);
	glColor3ub(179, 107, 0);
	glVertex2f(0.2f, 0.65f);
	glVertex2f(0.2f, 0.50f);
	glEnd();



    ///WIND_MILL_STAND///
	glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex2f(0.6f, 0.8f);
    glVertex2f(0.6f, 0.5f);
    glVertex2f(0.63f,0.5f);
    glVertex2f(0.63f, 0.8f);
    glEnd();




    /// SUN ///
    int i;
	GLfloat x=0.85f; GLfloat y=.9f; GLfloat radius =.08f;
	int triangleAmount = 20;


	GLfloat twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 255);
		glVertex2f(x, y);
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();




	  /// WIND_MILL ///

	glPushMatrix();
    glTranslatef(0.615,0.8,0);
	glScalef(0.5,0.5,0.0);
    glRotatef(f,0,0.0,0.2);

    glBegin(GL_TRIANGLES);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex2f(0.0f, 0.0f);
    glVertex2f(-0.2f, 0.4f);
    glVertex2f(-0.07f, 0.05f);
    glEnd();

    glBegin(GL_TRIANGLES);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex2f(0.0f, 0.0f);
    glVertex2f(0.4f, 0.05f);
    glVertex2f(0.05f, 0.05f);
    glEnd();

    glBegin(GL_TRIANGLES);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex2f(0.0f, 0.0f);
    glVertex2f(-0.2f, -0.4f);
    glVertex2f(0.01f, -0.06f);
    glEnd();


	glColor3f(0.5f, 0.5f, 0.5f);

	 x=0.0f; y=0.0f;  radius =0.04f;
	 triangleAmount = 20;


	 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f);

	x=-0.0f; y=-0.0f; radius =0.02f;
	triangleAmount = 20;


	twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

    glPopMatrix();


    f+=0.04f;///WINDMILLEND
    glLoadIdentity();




        /// HILLS ///
    glBegin(GL_TRIANGLES); ///HILLS1
    glColor3ub(0, 26, 0);
    glVertex2f(-0.65f, 0.5f);
    glVertex2f(0.2f, 0.5f);
    glVertex2f(-0.2f, 0.7f);
    glEnd();

    glBegin(GL_TRIANGLES); ///HILLS2
    glColor3ub(0, 26, 0);
    glVertex2f(0.15f, 0.5f);
    glVertex2f(0.8f, 0.5f);
    glVertex2f(0.35f, 0.7f);
    glEnd();

    glBegin(GL_TRIANGLES); ///HILLS3
    glColor3ub(0, 26, 0);
    glVertex2f(0.75f, 0.5f);
    glVertex2f(1.0f, 0.5f);
    glVertex2f(1.0f, 0.7f);
    glEnd();


       /// BUILDINGS ///
    glBegin(GL_QUADS);///BUILDINGS1
	glColor3ub(255, 80, 80);
    glVertex2f(-1.0f, 0.12f);
    glVertex2f(-0.70f, 0.12f);
    glVertex2f(-0.70f, 0.9f);
    glVertex2f(-1.0f, 0.9f);
    glEnd();

    glBegin(GL_QUADS);///WINDOW1
	glColor3ub(0,0,0);
    glVertex2f(-0.93f, 0.7f);
    glVertex2f(-0.83f, 0.7f);
    glVertex2f(-0.83f, 0.8f);
    glVertex2f(-0.93f, 0.8f);
    glEnd();

    glBegin(GL_QUADS);///WINDOW2
	glColor3ub(0,0,0);
    glVertex2f(-0.93f, 0.6f);
    glVertex2f(-0.83f, 0.6f);
    glVertex2f(-0.83f, 0.5f);
    glVertex2f(-0.93f, 0.5f);
    glEnd();

    glBegin(GL_QUADS);///WINDOW3
	glColor3ub(0,0,0);
    glVertex2f(-0.93f, 0.4f);
    glVertex2f(-0.83f, 0.4f);
    glVertex2f(-0.83f, 0.3f);
    glVertex2f(-0.93f, 0.3f);
    glEnd();


    glBegin(GL_QUADS);///BUILDINGS2
	glColor3ub(153, 153, 102);
    glVertex2f(-0.70f, 0.12f);
    glVertex2f(-0.35f, 0.12f);
    glVertex2f(-0.35f, 1.0f);
    glVertex2f(-0.70f, 1.0f);
    glEnd();

    glBegin(GL_QUADS);///WINDOW1
	glColor3ub(0,0,0);
    glVertex2f(-0.6f, 0.35f);
    glVertex2f(-0.45f, 0.35f);
    glVertex2f(-0.45f, 0.25f);
    glVertex2f(-0.6f, 0.25f);
    glEnd();

    glBegin(GL_QUADS);///WINDOW2
	glColor3ub(0,0,0);
    glVertex2f(-0.6f, 0.55f);
    glVertex2f(-0.45f, 0.55f);
    glVertex2f(-0.45f, 0.45f);
    glVertex2f(-0.6f, 0.45f);
    glEnd();

    glBegin(GL_QUADS);///WINDOW3
	glColor3ub(0,0,0);
    glVertex2f(-0.6f, 0.65f);
    glVertex2f(-0.45f, 0.65f);
    glVertex2f(-0.45f, 0.75f);
    glVertex2f(-0.6f, 0.75f);
    glEnd();

    glBegin(GL_QUADS);///WINDOW4
	glColor3ub(0,0,0);
    glVertex2f(-0.6f, 0.85f);
    glVertex2f(-0.45f, 0.85f);
    glVertex2f(-0.45f, 0.95f);
    glVertex2f(-0.6f, 0.95f);
    glEnd();


    /// RAIL_TRACK ///
    glBegin(GL_QUADS);///LINEGAP
	glColor3ub(153,153,102);
    glVertex2f(-1.0f, -0.3f);
    glVertex2f(-1.0f, -0.5f);
    glVertex2f(1.0f, -0.5f);
    glVertex2f(1.0f,-0.3f);
    glEnd();

    glLineWidth(4.0);///line1
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.3f);
	glVertex2f(1.0f, -0.3f);
    glEnd();

    glLineWidth(4.0);///line2
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.5f);
	glVertex2f(1.0f, -0.5f);
    glEnd();

    glLineWidth(5.0);///Track0
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-0.75f, -0.3f);
	glVertex2f(-0.9f, -0.5f);
    glEnd();

	glLineWidth(5.0);///Track1
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-0.55f, -0.3f);
	glVertex2f(-0.7f, -0.5f);
    glEnd();

	glLineWidth(5.0);///Track2
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-0.35f, -0.3f);
	glVertex2f(-0.5f, -0.5f);
    glEnd();

	glLineWidth(5.0);///Track3
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-0.15f, -0.3f);
	glVertex2f(-0.3f, -0.5f);
    glEnd();

	glLineWidth(5.0);///Track4
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(0.05f, -0.3f);
	glVertex2f(-0.1f, -0.5f);
    glEnd();

    glLineWidth(5.0);///Track5
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(0.25f, -0.3f);
	glVertex2f(0.1f, -0.5f);
    glEnd();

    glLineWidth(5.0);///Track6
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(0.45f, -0.3f);
	glVertex2f(0.3f, -0.5f);
    glEnd();

    glLineWidth(5.0);///Track7
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(0.65f, -0.3f);
	glVertex2f(0.5f, -0.5f);
    glEnd();

    glLineWidth(5.0);///Track8
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(0.85f, -0.3f);
	glVertex2f(0.7f, -0.5f);
    glEnd();

    glLineWidth(5.0);///Track9
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(1.05f, -0.3f);
	glVertex2f(0.9f, -0.5f);
    glEnd();



      ///THE TRAIN///

    glPushMatrix();
    glTranslatef(position,0.0f, 0.0f);
	 x=-.35f; y=-.4f; radius =.1f;
	 triangleAmount = 20;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,0,0);
		glVertex2f(x, y);
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();


    x=-.85f; y=-.4f; radius =.1f;
	triangleAmount = 20;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,0,0);
		glVertex2f(x, y);
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.10f; y=-.4f; radius =.1f;
	triangleAmount = 20;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,0,0);
		glVertex2f(x, y);
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();


	glLineWidth(2.5);///TRAINTOP
	glBegin(GL_QUADS);
	glColor3ub(0, 102, 255);
	glVertex2f(-1.0f, 0.12f);
	glVertex2f(-1.0f, 0.05f);
	glVertex2f(0.05f, 0.05f);
	glVertex2f(-0.02f, 0.12f);
    glEnd();

	glBegin(GL_QUADS);///UPPART
	glColor3ub(255, 204, 102);
    glVertex2f(-1.0f, 0.05f);
    glVertex2f(-1.0f, -0.1f);
    glVertex2f(0.05f, -0.1f);
    glVertex2f(0.05f, 0.05f);
    glEnd();

    glBegin(GL_QUADS);///MIDPART
	glColor3ub(0, 102, 255);
    glVertex2f(-1.0f, -0.27f);
    glVertex2f(0.2f, -0.27f);
	glVertex2f(0.2f, -0.1f);
	glVertex2f(-1.0f, -0.1f);
    glEnd();

    glBegin(GL_QUADS);///DOWNPART
	glColor3ub(128, 0, 0);
    glVertex2f(-1.0f, -0.27f);
    glVertex2f(-1.0f, -0.36f);
    glVertex2f(0.32f, -0.36f);
    glVertex2f(0.2f, -0.27f);
    glEnd();

    glLineWidth(7.0);///WHEELADJUSTER
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-.85f, -0.42f);
	glVertex2f(0.1f, -0.42f);
    glEnd();



    glLineWidth(2.0);///WINDOWLINE1
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-1.0f, 0.05f);
	glVertex2f(0.05f, 0.05f);
    glEnd();

    glLineWidth(2.0);///WINDOWLINE2
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-1.0f, 0.0f);
	glVertex2f(0.05f, 0.0f);
    glEnd();

    glLineWidth(2.0);///WINDOWLINE3
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.07f);
	glVertex2f(0.05f, -0.07f);
    glEnd();

    glLineWidth(2.0);///WINDOWLINE4
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.13f);
	glVertex2f(0.2f, -0.13f);
    glEnd();

    glLineWidth(2.0);///WINDOWLINE5
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.18f);
	glVertex2f(0.2f, -0.18f);
    glEnd();

    glLineWidth(2.0);///WINDOWLINE6
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.23f);
	glVertex2f(0.2f, -0.23f);
    glEnd();

    glBegin(GL_QUADS); ///WINDOW1
	glColor3ub(0,0,0);
    glVertex2f(-0.95f, 0.05f);
    glVertex2f(-0.95f, -0.06f);
    glVertex2f(-0.8f, -0.06f);
    glVertex2f(-0.8f, 0.05f);
    glEnd();

    glBegin(GL_QUADS); ///WINDOW1
	glColor3ub(0,0,0);
    glVertex2f(-0.7f, 0.05f);
    glVertex2f(-0.7f, -0.06f);
    glVertex2f(-0.55f, -0.06f);
    glVertex2f(-0.55f, 0.05f);
    glEnd();

    glBegin(GL_QUADS); ///WINDOW3
	glColor3ub(0,0,0);
    glVertex2f(-0.2f, 0.05f);
    glVertex2f(-0.2f, -0.06f);
    glVertex2f(-0.05f, -0.06f);
    glVertex2f(-0.05f, 0.05f);
    glEnd();

    glBegin(GL_QUADS);///DOOR
	glColor3ub(0,0,0);
    glVertex2f(-0.45f, 0.05f);
    glVertex2f(-0.45f, -0.25f);
    glVertex2f(-0.3f, -0.25f);
    glVertex2f(-0.3f, 0.05f);
    glEnd();
    glPopMatrix();


    glFlush();
}

void display2(int val){glutDisplayFunc(night);}




void day() {

	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT);

    ///SKY///
	glBegin(GL_QUADS);
	glColor3ub(102, 204, 255);
    glVertex2f(-1.0f, 1.0f);
    glVertex2f(-1.0f, 0.3f);
    glVertex2f(1.0f,0.3f);
    glVertex2f(1.0f, 1.0f);
    glEnd();

    ///BOAT///
    glPushMatrix();
    glTranslatef(position1,0.0f, 0.0f);
    glBegin(GL_QUADS);
	glColor3ub(0,0,0);
    glVertex2f(0.3f,0.4f);
    glVertex2f(0.4f, 0.35f);
    glVertex2f(0.6f,0.35f);
    glVertex2f(0.7f,0.4f);
    glEnd();

    ///BOATSTAND///
    glLineWidth(2.5);
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(0.62f, 0.32f);
	glVertex2f(0.62f, 0.48f);
    glEnd();
    glPopMatrix();

    ///GRASS///
    glBegin(GL_QUADS);
    glColor3ub(153, 204, 0);
    glVertex2f(-1.0f, -1.0f);
    glVertex2f(1.0f, -1.0f);
    glVertex2f(1.0f,0.3f);
    glVertex2f(-1.0f, 0.3f);
    glEnd();

    ///BIRD///
    glPushMatrix();
    glTranslatef(position,position, 0.0f);
    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2f(0.3f,0.4f);
    glVertex2f(0.35f, 0.35f);
    glVertex2f(0.4f,0.4f);
    glVertex2f(0.35f,0.38f);

    glEnd();
    glPopMatrix();


     ///TREE///
    glBegin(GL_POLYGON);
    glColor3ub(0, 102, 0);
    glVertex3f(0.2f, 0.90f, 0.0f);
    glVertex3f(0.1f, 0.80f, 0.0f);
    glVertex3f(0.1f, 0.70f, 0.0f);
    glVertex3f(0.2f,0.60f, 0.0f);
    glVertex3f(0.3f, 0.7f, 0.0f);
    glVertex3f(0.3f, 0.8f, 0.0f);
    glEnd();

    ///TREE///
    glLineWidth(7.5);
	glBegin(GL_LINES);
	glColor3ub(179, 107, 0);
	glVertex2f(0.2f, 0.65f);
	glVertex2f(0.2f, 0.50f);
	glEnd();



    ///WIND_MILL_STAND///
	glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex2f(0.6f, 0.8f);
    glVertex2f(0.6f, 0.5f);
    glVertex2f(0.63f,0.5f);
    glVertex2f(0.63f, 0.8f);
    glEnd();




    /// SUN ///
    int i;
	GLfloat x=0.8f; GLfloat y=.6f; GLfloat radius =.1f;
	int triangleAmount = 20;


	GLfloat twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 51, 0);
		glVertex2f(x, y);
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();




	  /// WIND_MILL ///

	glPushMatrix();
    glTranslatef(0.615,0.8,0);
	glScalef(0.5,0.5,0.0);
    glRotatef(f,0,0.0,0.2);

    glBegin(GL_TRIANGLES);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex2f(0.0f, 0.0f);
    glVertex2f(-0.2f, 0.4f);
    glVertex2f(-0.07f, 0.05f);
    glEnd();

    glBegin(GL_TRIANGLES);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex2f(0.0f, 0.0f);
    glVertex2f(0.4f, 0.05f);
    glVertex2f(0.05f, 0.05f);
    glEnd();

    glBegin(GL_TRIANGLES);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex2f(0.0f, 0.0f);
    glVertex2f(-0.2f, -0.4f);
    glVertex2f(0.01f, -0.06f);
    glEnd();


	glColor3f(0.5f, 0.5f, 0.5f);

	 x=0.0f; y=0.0f;  radius =0.04f;
	 triangleAmount = 20;


	 twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f);

	x=-0.0f; y=-0.0f; radius =0.02f;
	triangleAmount = 20;


	twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

    glPopMatrix();


    f+=0.04f;///WINDMILLEND
    glLoadIdentity();




        /// HILLS ///
    glBegin(GL_TRIANGLES); ///HILLS1
    glColor3ub(0, 102, 0);
    glVertex2f(-0.65f, 0.5f);
    glVertex2f(0.2f, 0.5f);
    glVertex2f(-0.2f, 0.7f);
    glEnd();

    glBegin(GL_TRIANGLES); ///HILLS2
    glColor3ub(0, 102, 0);
    glVertex2f(0.15f, 0.5f);
    glVertex2f(0.8f, 0.5f);
    glVertex2f(0.35f, 0.7f);
    glEnd();

    glBegin(GL_TRIANGLES); ///HILLS3
    glColor3ub(0, 102, 0);
    glVertex2f(0.75f, 0.5f);
    glVertex2f(1.0f, 0.5f);
    glVertex2f(1.0f, 0.7f);
    glEnd();


       /// BUILDINGS ///
    glBegin(GL_QUADS);///BUILDINGS1
	glColor3ub(255, 80, 80);
    glVertex2f(-1.0f, 0.12f);
    glVertex2f(-0.70f, 0.12f);
    glVertex2f(-0.70f, 0.9f);
    glVertex2f(-1.0f, 0.9f);
    glEnd();

    glBegin(GL_QUADS);///WINDOW1
	glColor3ub(0,0,0);
    glVertex2f(-0.93f, 0.7f);
    glVertex2f(-0.83f, 0.7f);
    glVertex2f(-0.83f, 0.8f);
    glVertex2f(-0.93f, 0.8f);
    glEnd();

    glBegin(GL_QUADS);///WINDOW2
	glColor3ub(0,0,0);
    glVertex2f(-0.93f, 0.6f);
    glVertex2f(-0.83f, 0.6f);
    glVertex2f(-0.83f, 0.5f);
    glVertex2f(-0.93f, 0.5f);
    glEnd();

    glBegin(GL_QUADS);///WINDOW3
	glColor3ub(0,0,0);
    glVertex2f(-0.93f, 0.4f);
    glVertex2f(-0.83f, 0.4f);
    glVertex2f(-0.83f, 0.3f);
    glVertex2f(-0.93f, 0.3f);
    glEnd();


    glBegin(GL_QUADS);///BUILDINGS2
	glColor3ub(153, 153, 102);
    glVertex2f(-0.70f, 0.12f);
    glVertex2f(-0.35f, 0.12f);
    glVertex2f(-0.35f, 1.0f);
    glVertex2f(-0.70f, 1.0f);
    glEnd();

    glBegin(GL_QUADS);///WINDOW1
	glColor3ub(0,0,0);
    glVertex2f(-0.6f, 0.35f);
    glVertex2f(-0.45f, 0.35f);
    glVertex2f(-0.45f, 0.25f);
    glVertex2f(-0.6f, 0.25f);
    glEnd();

    glBegin(GL_QUADS);///WINDOW2
	glColor3ub(0,0,0);
    glVertex2f(-0.6f, 0.55f);
    glVertex2f(-0.45f, 0.55f);
    glVertex2f(-0.45f, 0.45f);
    glVertex2f(-0.6f, 0.45f);
    glEnd();

    glBegin(GL_QUADS);///WINDOW3
	glColor3ub(0,0,0);
    glVertex2f(-0.6f, 0.65f);
    glVertex2f(-0.45f, 0.65f);
    glVertex2f(-0.45f, 0.75f);
    glVertex2f(-0.6f, 0.75f);
    glEnd();

    glBegin(GL_QUADS);///WINDOW4
	glColor3ub(0,0,0);
    glVertex2f(-0.6f, 0.85f);
    glVertex2f(-0.45f, 0.85f);
    glVertex2f(-0.45f, 0.95f);
    glVertex2f(-0.6f, 0.95f);
    glEnd();


    /// RAIL_TRACK ///
    glBegin(GL_QUADS);///LINEGAP
	glColor3ub(153,153,102);
    glVertex2f(-1.0f, -0.3f);
    glVertex2f(-1.0f, -0.5f);
    glVertex2f(1.0f, -0.5f);
    glVertex2f(1.0f,-0.3f);
    glEnd();

    glLineWidth(4.0);///line1
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.3f);
	glVertex2f(1.0f, -0.3f);
    glEnd();

    glLineWidth(4.0);///line2
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.5f);
	glVertex2f(1.0f, -0.5f);
    glEnd();

    glLineWidth(5.0);///Track0
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-0.75f, -0.3f);
	glVertex2f(-0.9f, -0.5f);
    glEnd();

	glLineWidth(5.0);///Track1
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-0.55f, -0.3f);
	glVertex2f(-0.7f, -0.5f);
    glEnd();

	glLineWidth(5.0);///Track2
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-0.35f, -0.3f);
	glVertex2f(-0.5f, -0.5f);
    glEnd();

	glLineWidth(5.0);///Track3
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-0.15f, -0.3f);
	glVertex2f(-0.3f, -0.5f);
    glEnd();

	glLineWidth(5.0);///Track4
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(0.05f, -0.3f);
	glVertex2f(-0.1f, -0.5f);
    glEnd();

    glLineWidth(5.0);///Track5
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(0.25f, -0.3f);
	glVertex2f(0.1f, -0.5f);
    glEnd();

    glLineWidth(5.0);///Track6
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(0.45f, -0.3f);
	glVertex2f(0.3f, -0.5f);
    glEnd();

    glLineWidth(5.0);///Track7
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(0.65f, -0.3f);
	glVertex2f(0.5f, -0.5f);
    glEnd();

    glLineWidth(5.0);///Track8
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(0.85f, -0.3f);
	glVertex2f(0.7f, -0.5f);
    glEnd();

    glLineWidth(5.0);///Track9
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(1.05f, -0.3f);
	glVertex2f(0.9f, -0.5f);
    glEnd();



      ///THE TRAIN///

    glPushMatrix();
    glTranslatef(position,0.0f, 0.0f);
	 x=-.35f; y=-.4f; radius =.1f;
	 triangleAmount = 20;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,0,0);
		glVertex2f(x, y);
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();


    x=-.85f; y=-.4f; radius =.1f;
	triangleAmount = 20;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,0,0);
		glVertex2f(x, y);
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	 x=0.10f; y=-.4f; radius =.1f;
	triangleAmount = 20;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0,0,0);
		glVertex2f(x, y);
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();


	glLineWidth(2.5);///TRAINTOP
	glBegin(GL_QUADS);
	glColor3ub(0, 102, 255);
	glVertex2f(-1.0f, 0.12f);
	glVertex2f(-1.0f, 0.05f);
	glVertex2f(0.05f, 0.05f);
	glVertex2f(-0.02f, 0.12f);
    glEnd();

	glBegin(GL_QUADS);///UPPART
	glColor3ub(255, 204, 102);
    glVertex2f(-1.0f, 0.05f);
    glVertex2f(-1.0f, -0.1f);
    glVertex2f(0.05f, -0.1f);
    glVertex2f(0.05f, 0.05f);
    glEnd();

    glBegin(GL_QUADS);///MIDPART
	glColor3ub(0, 102, 255);
    glVertex2f(-1.0f, -0.27f);
    glVertex2f(0.2f, -0.27f);
	glVertex2f(0.2f, -0.1f);
	glVertex2f(-1.0f, -0.1f);
    glEnd();

    glBegin(GL_QUADS);///DOWNPART
	glColor3ub(128, 0, 0);
    glVertex2f(-1.0f, -0.27f);
    glVertex2f(-1.0f, -0.36f);
    glVertex2f(0.32f, -0.36f);
    glVertex2f(0.2f, -0.27f);
    glEnd();

    glLineWidth(7.0);///WHEELADJUSTER
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-.85f, -0.42f);
	glVertex2f(0.1f, -0.42f);
    glEnd();



    glLineWidth(2.0);///WINDOWLINE1
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-1.0f, 0.05f);
	glVertex2f(0.05f, 0.05f);
    glEnd();

    glLineWidth(2.0);///WINDOWLINE2
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-1.0f, 0.0f);
	glVertex2f(0.05f, 0.0f);
    glEnd();

    glLineWidth(2.0);///WINDOWLINE3
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.07f);
	glVertex2f(0.05f, -0.07f);
    glEnd();

    glLineWidth(2.0);///WINDOWLINE4
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.13f);
	glVertex2f(0.2f, -0.13f);
    glEnd();

    glLineWidth(2.0);///WINDOWLINE5
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.18f);
	glVertex2f(0.2f, -0.18f);
    glEnd();

    glLineWidth(2.0);///WINDOWLINE6
	glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.23f);
	glVertex2f(0.2f, -0.23f);
    glEnd();

    glBegin(GL_QUADS); ///WINDOW1
	glColor3ub(0,0,0);
    glVertex2f(-0.95f, 0.05f);
    glVertex2f(-0.95f, -0.06f);
    glVertex2f(-0.8f, -0.06f);
    glVertex2f(-0.8f, 0.05f);
    glEnd();

    glBegin(GL_QUADS); ///WINDOW1
	glColor3ub(0,0,0);
    glVertex2f(-0.7f, 0.05f);
    glVertex2f(-0.7f, -0.06f);
    glVertex2f(-0.55f, -0.06f);
    glVertex2f(-0.55f, 0.05f);
    glEnd();

    glBegin(GL_QUADS); ///WINDOW3
	glColor3ub(0,0,0);
    glVertex2f(-0.2f, 0.05f);
    glVertex2f(-0.2f, -0.06f);
    glVertex2f(-0.05f, -0.06f);
    glVertex2f(-0.05f, 0.05f);
    glEnd();

    glBegin(GL_QUADS);///DOOR
	glColor3ub(0,0,0);
    glVertex2f(-0.45f, 0.05f);
    glVertex2f(-0.45f, -0.25f);
    glVertex2f(-0.3f, -0.25f);
    glVertex2f(-0.3f, 0.05f);
    glEnd();
    glPopMatrix();

    glutTimerFunc(2500,display2,0);

    glFlush();
}

void dis(){glutDisplayFunc(day);}




 ///MOUSEHANDLE///
void handleMouse(int button, int state, int x, int y) {
	if (button == GLUT_LEFT_BUTTON)
	{	speed -= 0.1f;
        speed1 -= 0.1f;
			}
if (button == GLUT_RIGHT_BUTTON)
	{ speed += 0.1f;
	  speed1 += 0.1f;   }

    glutPostRedisplay();}



    ///KEY_HANDLE///
void handleKeypress(unsigned char key, int x, int y) {
	switch (key) {
case 's':
    speed = 0.0f;
    speed1 = 0.0f;
    break;
case 'r':
    speed = 0.1f;
    speed1 = 0.05f;
    break;
case 'd':
   glutDisplayFunc(day);
   glutPostRedisplay();
    break;
case 'n':
   glutDisplayFunc(night);
   glutPostRedisplay();
    break;

	}}


///SPECIAL_INPUT_HANDLE///
void SpecialInput(int key, int x, int y)
{
switch(key)
{
case GLUT_KEY_UP:

 speed = 0.7f;
 speed1 = 0.7f;
break;

case GLUT_KEY_DOWN:
  speed = 0.1f;
  speed1 = 0.05f;
  break;

case GLUT_KEY_LEFT:
break;

case GLUT_KEY_RIGHT:
break;
}
glutPostRedisplay();
}





int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutCreateWindow("Translation Animation");
	glutInitWindowSize(320, 320);
	glutInitWindowPosition(50, 50);
	glutDisplayFunc(dis);
	glutIdleFunc(Idle);

    glutTimerFunc(150, update, 0);
	glutTimerFunc(200, update1, 0);

    glutKeyboardFunc(handleKeypress);
    glutMouseFunc(handleMouse);
    glutSpecialFunc(SpecialInput);


	glutMainLoop();
	return 0;
}

