#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include<math.h>
# define PI           3.14159265358979323846
#include<cstdio>
#include <GL/gl.h>
#include <GL/glut.h>

/* Handler for window-repaint event. Call back when the window first appears and
whenever the window needs to be re-painted. */

GLfloat i=0.0f;
GLfloat j=0.0f;
GLfloat position = 0.0f;
GLfloat speed = 0.1f;

void update(int value) {

    if(position >1.0)
    position = -1.0f;

    position += speed;

	glutPostRedisplay();


	glutTimerFunc(100, update, 0);
}

void Idle()
{
    glutPostRedisplay(); // marks the current window as needing to be redisplayed
}


void display() {
	glClearColor(0.0f, 153.0f, 255.0f, 0.0f); // Set background color to black and opaque
	glClear(GL_COLOR_BUFFER_BIT);         // Clear the color buffer (background)

    // Clear the color buffer (background)



     //bulding

     glTranslatef(-0.3,-0.2, 0);
     glBegin(GL_QUADS);              // Each set of 4 vertices form a quad
	 glColor3f(1.0f, 0.0f, 1.0f); // Paste colour
	 glVertex2f(0.0f, 0.2f);    // x, y
	 glVertex2f(0.0f, 0.4f);    // x, y
     glVertex2f(0.4f, 0.4f);
     glVertex2f(0.4f, 0.2f);
	 glEnd();
     glLoadIdentity();

     glTranslatef(-0.3,-0.2, 0);
     glBegin(GL_TRIANGLES);
     glColor3ub(204, 51, 0);  //Green
     glVertex2f(0.5f, 0.4f);
     glVertex2f(0.2f, 0.6f);
     glVertex2f(-0.1f, 0.4f);
     glEnd();
     glLoadIdentity();

     glTranslatef(-0.3,-0.2, 0);
     glBegin(GL_QUADS);              // Each set of 4 vertices form a quad
 	 glColor3f(1.0f, 1.0f, 1.0f); // White
     glVertex2f(0.225f, 0.2f);    // x, y
	 glVertex2f(0.225f, 0.3f);    // x, y
     glVertex2f(0.175f, 0.3f);
     glVertex2f(0.175f, 0.2f);
	 glEnd();


     //tree

     glLoadIdentity();
     glTranslatef(0.21, 0.5, 0.0);
     glBegin(GL_QUADS);
     glColor3ub(102, 34, 0);
     glVertex2f(-0.9f, -0.5f);
     glVertex2f(-0.9f, -0.1f);// x, y
     glVertex2f(-0.85f, -0.1f);
     glVertex2f(-.85f, -0.5f);// x, y
     glEnd();
     glLoadIdentity();

     glTranslatef(0.2, 0.5, 0.0);
     glBegin(GL_TRIANGLES);
     glColor3ub(0, 255, 0);
     glVertex2f(-1.1f, -0.1f);
     glVertex2f(-0.85f, 0.1f);// x, y
     glVertex2f(-0.6f, -0.1f);
     glEnd();
     glLoadIdentity();

     glTranslatef(0.2, 0.5, 0.0);
     glBegin(GL_TRIANGLES);
     glColor3ub(0, 255, 0);
     glVertex2f(-1.1f, -0.2f);
     glVertex2f(-0.85f, 0.0f);// x, y
     glVertex2f(-0.6f, -0.2f);
     glEnd();



     //Roads

     glLoadIdentity();
     glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	 glColor3ub(1.0f, 1.0f, 1.0f); // White
	 glVertex2f(-1.0f, -0.6f);    // x, y
	 glVertex2f(0.0f, -0.6f);    // x, y
	 glVertex2f(0.0f, -0.6f);    // x, y
	 glVertex2f(1.0f, -0.6f);    // x, y

	 glEnd();


     glBegin(GL_QUADS);
     glColor3ub(38, 38, 38);

     glVertex2f(-1.00f, -0.5f);
     glVertex2f(1.00f, -0.5f);// x, y
     glVertex2f(1.00f, -0.95f);
     glVertex2f(-1.00f, -0.95f);// x, y
     glEnd();


     glBegin(GL_QUADS);
     glColor3ub(255, 255, 255);

     glVertex2f(-0.7f, -0.65f);
     glVertex2f(-0.5f, -0.65f);// x, y
     glVertex2f(-0.5f, -0.75f);
     glVertex2f(-0.7f, -0.75f);// x, y
     glEnd();

     glBegin(GL_QUADS);
     glColor3ub(255, 255, 255);

     glVertex2f(-0.99f, -0.65f);
     glVertex2f(-0.9f, -0.65f);// x, y
     glVertex2f(-0.9f, -0.75f);
     glVertex2f(-0.99f, -0.75f);// x, y
     glEnd();

     glBegin(GL_QUADS);
     glColor3ub(255, 255, 255);

     glVertex2f(-0.3f, -0.65f);
     glVertex2f(-0.1f, -0.65f);// x, y
     glVertex2f(-0.1f, -0.75f);
     glVertex2f(-0.3f, -0.75f);// x, y
     glEnd();

     glBegin(GL_QUADS);
     glColor3ub(255, 255, 255);

     glVertex2f(0.1f, -0.65f);
     glVertex2f(0.3f, -0.65f);// x, y
     glVertex2f(0.3f, -0.75f);
     glVertex2f(0.1f, -0.75f);// x, y
     glEnd();

     glBegin(GL_QUADS);
     glColor3ub(255, 255, 255);

     glVertex2f(0.5f, -0.65f);
     glVertex2f(0.7f, -0.65f);// x, y
     glVertex2f(0.7f, -0.75f);
     glVertex2f(0.5f, -0.75f);// x, y
     glEnd();

     glBegin(GL_QUADS);
     glColor3ub(245, 245, 245);

     glVertex2f(0.9f, -0.65f);
     glVertex2f(0.99f, -0.65f);// x, y
     glVertex2f(0.99f, -0.75f);
     glVertex2f(0.9f, -0.75f);// x, y
     glEnd();


     ////plane***********

     glPushMatrix();
     glTranslatef(position,0.0f, 0.0f);
     glBegin(GL_QUADS);
     glColor3ub(245, 245, 245);

     glVertex2f(-0.7f, -0.35f);
     glVertex2f(0.2f, -0.35f);// x, y
     glVertex2f(0.2f, -0.55f);
     glVertex2f(-0.7f, -0.55f);// x, y
     glEnd();


     glBegin(GL_TRIANGLES);
     glColor3ub(245, 245, 245);

     glVertex2f(0.2f, -0.35f);
     glVertex2f(0.4f, -0.55f);// x, y
     glVertex2f(0.2f, -0.55f);
     glEnd();

     glBegin(GL_TRIANGLES);
     glColor3ub(245, 245, 245);

     glVertex2f(-0.7f, -0.45f);
     glVertex2f(-0.55f, -0.35f);// x, y
     glVertex2f(-0.7f, -0.15f);
     glEnd();

     glBegin(GL_TRIANGLES);
     glColor3ub(245, 245, 245);

     glVertex2f(-0.2f, -0.45f);
     glVertex2f(0.0f, -0.35f);// x, y
     glVertex2f(-0.2f, -0.15f);
     glEnd();


	 GLfloat x=-.5f; GLfloat y=-.6f; GLfloat radius =.05f;
	 int triangleAmount = 30; //# of triangles used to draw circle

	  //GLfloat radius = 0.8f; //radius
	 GLfloat twicePi = 2.0f * PI;

     glBegin(GL_TRIANGLE_FAN);
	 glColor3ub(0,0,255);
     glVertex2f(x, y); // center of circle
     for(i = 0; i <= triangleAmount;i++)
            {
			glVertex2f(x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount)));
		    }
	 glEnd();

	 x=0.25f; y=-0.6f;radius =0.05f;
     glBegin(GL_TRIANGLE_FAN);
	 glColor3ub(0,0,255);
     glVertex2f(x, y); // center of circle
     for(i = 0; i <= triangleAmount;i++)
            {
			glVertex2f(x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount)));
		    }

	 glEnd();

     x=0.15f; y=-0.45f;radius =0.02f;
     glBegin(GL_TRIANGLE_FAN);
	 glColor3ub(0,51,0);
     glVertex2f(x, y); // center of circle
     for(i = 0; i <= triangleAmount;i++)
            {
			glVertex2f(x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount)));
		    }

	 glEnd();

     x=-0.15f; y=-0.45f;radius =0.02f;
     glBegin(GL_TRIANGLE_FAN);
	 glColor3ub(0,51,0);
     glVertex2f(x, y); // center of circle
     for(i = 0; i <= triangleAmount;i++)
            {
			glVertex2f(x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount)));
		    }
	 glEnd();

     x=-.35f; y=-.45f;radius =.02f;
     glBegin(GL_TRIANGLE_FAN);
	 glColor3ub(0,51,0);
     glVertex2f(x, y); // center of circle
     for(i = 0; i <= triangleAmount;i++)
            {
			glVertex2f(x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount)));
		    }
	 glEnd();

     x=-.45f; y=-.45f;radius =.02f;
     glBegin(GL_TRIANGLE_FAN);
	 glColor3ub(0,51,0);
     glVertex2f(x, y); // center of circle
     for(i = 0; i <= triangleAmount;i++)
            {
			glVertex2f(x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount)));
		    }
	glEnd();

    glPopMatrix();


    // Sun-------

    x=-0.8f; y=0.8f; radius =0.2f;
    glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 0);
    glVertex2f(x, y);
    for(i = 0; i <= triangleAmount;i++) {
    glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();


    //-----Windmill-------

    glTranslatef(1.0, 0.5, 0);
    glBegin(GL_QUADS);
    glColor3ub(204, 51, 0);
    glVertex2f(-0.55f, -0.5f);
    glVertex2f( -0.45f, -0.5f);
    glVertex2f( -0.47f, 0.06f);
    glVertex2f( -0.53f, 0.06f);
    glEnd();


    glPushMatrix();
    glTranslatef(-0.5, 0.06,0);
    glRotatef(j,0,0.0,0.1);//i=how many degree you want to rotate around an axis
    glBegin(GL_TRIANGLES);
    glColor3ub(235, 235, 224);//Blade
    glVertex2f(0.0f, 0.0f);
    glVertex2f( 0.05f, 0.3f);
    glVertex2f( -0.05f, 0.3f);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(235, 235, 224);//Blade
    glVertex2f(0.0f, 0.0f);
    glVertex2f( -0.05f, -0.3f);
    glVertex2f( 0.05f, -0.3f);
    glEnd();

    glPopMatrix();

    j-= 0.1f; //clock wise




	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0, 0, 0);
    glVertex2f(x, y); //windmill holding
    for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
    glEnd();
    glLoadIdentity();



	glFlush();  // Render now



}

////Main Function
int main(int argc, char** argv) {
	glutInit(&argc, argv);             // Initialize GLUT
	glutCreateWindow("Airport View"); // Create a window with the given title
	glutInitWindowSize(320, 320); // Set the window's initial width & height
	glutInitWindowPosition(50, 50);
	glutDisplayFunc(display); // Register display callback handler for window re-paint

	glutTimerFunc(100, update,0);
    glutIdleFunc(Idle); //glutIdleFunc sets the global idle callback to be func so a GLUT program can perform background processing tasks or continuous animation when window system events are not being received.
	glutMainLoop();           // Enter the event-processing loop
	return 0;
}
