#include<windows.h>
#include<GL/glut.h>
#include<math.h>>
# define PI           3.14159265358979323846
GLfloat j=0.0f;
GLfloat speed = 0.02f;

void idle()
{
    glutPostRedisplay();
}
void display()
{
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    glColor3ub(255, 255, 255);
    int i;

    GLfloat x=0.0f; GLfloat y=0.0f; GLfloat radius =0.2f;
    int triangleAmount = 30;

    GLfloat twicePi = 2.0f * PI;

    glBegin(GL_TRIANGLE_FAN);
        glVertex2f(x, y);
        for(i = 0; i <= triangleAmount;i++) {
            glVertex2f(
                    x + (radius * cos(i *  twicePi / triangleAmount)),
                y + (radius * sin(i * twicePi / triangleAmount))
            );
        }
    glEnd();
    glLoadIdentity();
    glTranslatef(0,0,0);


    glPushMatrix();
    glRotatef(j,0.0,0.0,0.1);

    glBegin(GL_TRIANGLES);
    glColor3ub(255, 255, 255);
    glVertex2f(-0.05,0.2);
    glVertex2f(0,0.3);
    glVertex2f(0.05,0.2);
    glEnd();


    glBegin(GL_TRIANGLES);
    glColor3ub(255, 255, 255);
    glVertex2f(-0.05,-0.2);
    glVertex2f(0,-0.3);
    glVertex2f(0.05,-0.2);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(255, 255, 255);
    glVertex2f(0.2,0.05);
    glVertex2f(0.3,0);
    glVertex2f(0.2,-0.05);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(255, 255, 255);
    glVertex2f(-0.2,0.05);
    glVertex2f(-0.3,0);
    glVertex2f(-0.2,-0.05);
    glEnd();


    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(-0.1,0.25);
    glVertex2f(-0.05,0.8);
    glVertex2f(0.05,0.8);
    glVertex2f(0.1,0.25);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(-0.1,-0.25);
    glVertex2f(-0.05,-0.8);
    glVertex2f(0.05,-0.8);
    glVertex2f(0.1,-0.25);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(0.25,0.1);
    glVertex2f(0.8,0.05);
    glVertex2f(0.8,-0.05);
    glVertex2f(0.25,-0.1);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(-0.25,0.1);
    glVertex2f(-0.8,0.05);
    glVertex2f(-0.8,-0.05);
    glVertex2f(-0.25,-0.1);
    glEnd();


    glLoadIdentity();
    glPopMatrix();
    j-=speed;


    glFlush();
}

void handleKeypress(unsigned char key, int x, int y)
{

    switch (key)
    {

case 'a':
    speed=0.0f;
    break;
case 'b':
    speed=0.02f;
    break;

case 'c':
    speed=0.06;
    break;

case 'd':
    speed=0.10;
    break;


glutPostRedisplay();

    }
}
void handleMouse(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON)
    {    speed += 0.1f;
            }
if (button == GLUT_RIGHT_BUTTON)
    {speed -= 0.1f;   }
glutPostRedisplay();}


int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutCreateWindow("Controlling Celling Fan");
    glutInitWindowSize(350,350);
    glutDisplayFunc(display);
    glutKeyboardFunc(handleKeypress);
    glutMouseFunc(handleMouse);
    glutIdleFunc(idle);
    glutMainLoop();
    return 0;
}

