#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include<math.h>
# define PI    3.14159265358979323846
#include<cstdio>
#include <GL/gl.h>
#include <GL/glut.h>

/* Handler for window-repaint event. Call back when the window first appears and
whenever the window needs to be re-painted. */

GLfloat i=0.0f;
GLfloat j=0.0f;
GLfloat position1 = 0.0f;
GLfloat position2 = 0.0f;

GLfloat speed1 = 0.1f;
GLfloat speed2 = 0.02f;

void update1(int value) {

    if(position1 >1.0)
    position1 = -1.0f;

    position1 += speed1;

	glutPostRedisplay();

    glutTimerFunc(100, update1, 0);
}

void update2(int value) {

    if(position2 <-1.0)
    position2 = 1.0f;

    position2 -= speed2;

	glutPostRedisplay();

	glutTimerFunc(100, update2, 0);
}

void Idle()
{
    glutPostRedisplay(); // marks the current window as needing to be redisplayed
}


GLfloat Rainposition = 0.0f;
GLfloat RainSpeed = 0.06f;

void Rain(int value) {

    if(Rainposition <0.0)
        Rainposition = 0.2f;

    Rainposition -= RainSpeed;

	glutPostRedisplay();


	glutTimerFunc(100, Rain, 0);
}

void display() {
	 glClearColor(0.0f, 153.0f, 255.0f, 0.0f); // Set background color to black and opaque
	 glClear(GL_COLOR_BUFFER_BIT);         // Clear the color buffer (background)

     // Clear the color buffer (background)


     //bulding

     glTranslatef(-0.3,-0.2, 0);
     glBegin(GL_QUADS);              // Each set of 4 vertices form a quad
	 glColor3f(1.0f, 0.0f, 1.0f); // Paste colour
	 glVertex2f(0.0f, 0.2f);    // x, y
	 glVertex2f(0.0f, 0.4f);    // x, y
     glVertex2f(0.4f, 0.4f);
     glVertex2f(0.4f, 0.2f);
	 glEnd();
     glLoadIdentity();

     glTranslatef(-0.3,-0.2, 0);
     glBegin(GL_TRIANGLES);
     glColor3ub(204, 51, 0);  //Green
     glVertex2f(0.5f, 0.4f);
     glVertex2f(0.2f, 0.6f);
     glVertex2f(-0.1f, 0.4f);
     glEnd();
     glLoadIdentity();

     glTranslatef(-0.3,-0.2, 0);
     glBegin(GL_QUADS);              // Each set of 4 vertices form a quad
 	 glColor3f(1.0f, 1.0f, 1.0f); // White
     glVertex2f(0.225f, 0.2f);    // x, y
	 glVertex2f(0.225f, 0.3f);    // x, y
     glVertex2f(0.175f, 0.3f);
     glVertex2f(0.175f, 0.2f);
	 glEnd();


     //tree

     glLoadIdentity();
     glTranslatef(0.21, 0.5, 0.0);
     glBegin(GL_QUADS);
     glColor3ub(102, 34, 0);
     glVertex2f(-0.9f, -0.5f);
     glVertex2f(-0.9f, -0.1f);// x, y
     glVertex2f(-0.85f, -0.1f);
     glVertex2f(-.85f, -0.5f);// x, y
     glEnd();
     glLoadIdentity();

     glTranslatef(0.2, 0.5, 0.0);
     glBegin(GL_TRIANGLES);
     glColor3ub(0, 255, 0);
     glVertex2f(-1.1f, -0.1f);
     glVertex2f(-0.85f, 0.1f);// x, y
     glVertex2f(-0.6f, -0.1f);
     glEnd();
     glLoadIdentity();

     glTranslatef(0.2, 0.5, 0.0);
     glBegin(GL_TRIANGLES);
     glColor3ub(0, 255, 0);
     glVertex2f(-1.1f, -0.2f);
     glVertex2f(-0.85f, 0.0f);// x, y
     glVertex2f(-0.6f, -0.2f);
     glEnd();


     //Roads

     glLoadIdentity();
     glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	 glColor3ub(1.0f, 1.0f, 1.0f); // White
	 glVertex2f(-1.0f, -0.6f);    // x, y
	 glVertex2f(0.0f, -0.6f);    // x, y
	 glVertex2f(0.0f, -0.6f);    // x, y
	 glVertex2f(1.0f, -0.6f);    // x, y

	 glEnd();

     glBegin(GL_QUADS);
     glColor3ub(38, 38, 38);

     glVertex2f(-1.00f, -0.5f);
     glVertex2f(1.00f, -0.5f);// x, y
     glVertex2f(1.00f, -0.95f);
     glVertex2f(-1.00f, -0.95f);// x, y
     glEnd();


     glBegin(GL_QUADS);
     glColor3ub(255, 255, 255);

     glVertex2f(-0.7f, -0.65f);
     glVertex2f(-0.5f, -0.65f);// x, y
     glVertex2f(-0.5f, -0.75f);
     glVertex2f(-0.7f, -0.75f);// x, y
     glEnd();

     glBegin(GL_QUADS);
     glColor3ub(255, 255, 255);

     glVertex2f(-0.99f, -0.65f);
     glVertex2f(-0.9f, -0.65f);// x, y
     glVertex2f(-0.9f, -0.75f);
     glVertex2f(-0.99f, -0.75f);// x, y
     glEnd();

     glBegin(GL_QUADS);
     glColor3ub(255, 255, 255);

     glVertex2f(-0.3f, -0.65f);
     glVertex2f(-0.1f, -0.65f);// x, y
     glVertex2f(-0.1f, -0.75f);
     glVertex2f(-0.3f, -0.75f);// x, y
     glEnd();

     glBegin(GL_QUADS);
     glColor3ub(255, 255, 255);

     glVertex2f(0.1f, -0.65f);
     glVertex2f(0.3f, -0.65f);// x, y
     glVertex2f(0.3f, -0.75f);
     glVertex2f(0.1f, -0.75f);// x, y
     glEnd();

     glBegin(GL_QUADS);
     glColor3ub(255, 255, 255);

     glVertex2f(0.5f, -0.65f);
     glVertex2f(0.7f, -0.65f);// x, y
     glVertex2f(0.7f, -0.75f);
     glVertex2f(0.5f, -0.75f);// x, y
     glEnd();

     glBegin(GL_QUADS);
     glColor3ub(245, 245, 245);

     glVertex2f(0.9f, -0.65f);
     glVertex2f(0.99f, -0.65f);// x, y
     glVertex2f(0.99f, -0.75f);
     glVertex2f(0.9f, -0.75f);// x, y
     glEnd();


     ////plane***********

     glPushMatrix();
     glTranslatef(position1,0.0f, 0.0f);
     glBegin(GL_QUADS);
     glColor3ub(245, 245, 245);

     glVertex2f(-0.7f, -0.35f);
     glVertex2f(0.2f, -0.35f);// x, y
     glVertex2f(0.2f, -0.55f);
     glVertex2f(-0.7f, -0.55f);// x, y
     glEnd();

     glBegin(GL_TRIANGLES);
     glColor3ub(245, 245, 245);

     glVertex2f(0.2f, -0.35f);
     glVertex2f(0.4f, -0.55f);// x, y
     glVertex2f(0.2f, -0.55f);
     glEnd();

     glBegin(GL_TRIANGLES);
     glColor3ub(245, 245, 245);

     glVertex2f(-0.7f, -0.45f);
     glVertex2f(-0.55f, -0.35f);// x, y
     glVertex2f(-0.7f, -0.15f);
     glEnd();

     glBegin(GL_TRIANGLES);
     glColor3ub(245, 245, 245);

     glVertex2f(-0.2f, -0.45f);
     glVertex2f(0.0f, -0.35f);// x, y
     glVertex2f(-0.2f, -0.15f);
     glEnd();


	 GLfloat x=-.5f; GLfloat y=-.6f; GLfloat radius =.05f;
	 int triangleAmount = 30; //# of triangles used to draw circle

	  //GLfloat radius = 0.8f; //radius
	 GLfloat twicePi = 2.0f * PI;

     glBegin(GL_TRIANGLE_FAN);
	 glColor3ub(0,0,255);
     glVertex2f(x, y); // center of circle
     for(i = 0; i <= triangleAmount;i++)
            {
			glVertex2f(x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount)));
		    }
	 glEnd();

	 x=0.25f; y=-0.6f;radius =0.05f;
     glBegin(GL_TRIANGLE_FAN);
	 glColor3ub(0,0,255);
     glVertex2f(x, y); // center of circle
     for(i = 0; i <= triangleAmount;i++)
            {
			glVertex2f(x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount)));
		    }

	 glEnd();

     x=0.15f; y=-0.45f;radius =0.02f;
     glBegin(GL_TRIANGLE_FAN);
	 glColor3ub(0,51,0);
     glVertex2f(x, y); // center of circle
     for(i = 0; i <= triangleAmount;i++)
            {
			glVertex2f(x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount)));
		    }

	 glEnd();

     x=-0.15f; y=-0.45f;radius =0.02f;
     glBegin(GL_TRIANGLE_FAN);
	 glColor3ub(0,51,0);
     glVertex2f(x, y); // center of circle
     for(i = 0; i <= triangleAmount;i++)
            {
			glVertex2f(x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount)));
		    }
	 glEnd();

     x=-.35f; y=-.45f;radius =.02f;
     glBegin(GL_TRIANGLE_FAN);
	 glColor3ub(0,51,0);
     glVertex2f(x, y); // center of circle
     for(i = 0; i <= triangleAmount;i++)
            {
			glVertex2f(x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount)));
		    }
	 glEnd();

     x=-.45f; y=-.45f;radius =.02f;
     glBegin(GL_TRIANGLE_FAN);
	 glColor3ub(0,51,0);
     glVertex2f(x, y); // center of circle
     for(i = 0; i <= triangleAmount;i++)
            {
			glVertex2f(x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount)));
		    }
	glEnd();

    glPopMatrix();


    // Sun-------

    x=-0.85f; y=0.85f; radius =0.2f;
    glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 0);
    glVertex2f(x, y);
    for(i = 0; i <= triangleAmount;i++) {
    glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();


    //-----Windmill-------

    glTranslatef(1.0, 0.5, 0);
    glBegin(GL_QUADS);
    glColor3ub(204, 51, 0);
    glVertex2f(-0.55f, -0.5f);
    glVertex2f( -0.45f, -0.5f);
    glVertex2f( -0.47f, 0.06f);
    glVertex2f( -0.53f, 0.06f);
    glEnd();

    glPushMatrix();
    glTranslatef(-0.5, 0.06,0);
    glRotatef(j,0,0.0,0.1);//i=how many degree you want to rotate around an axis
    glBegin(GL_TRIANGLES);
    glColor3ub(235, 235, 224);//Blade
    glVertex2f(0.0f, 0.0f);
    glVertex2f( 0.05f, 0.3f);
    glVertex2f( -0.05f, 0.3f);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(235, 235, 224);//Blade
    glVertex2f(0.0f, 0.0f);
    glVertex2f( -0.05f, -0.3f);
    glVertex2f( 0.05f, -0.3f);
    glEnd();

    glPopMatrix();

    j-= 0.1f; //clock wise

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0, 0, 0);
    glVertex2f(x, y); //windmill holding
    for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
    glEnd();
    glLoadIdentity();

    //Clouds==================

    // Cloud 1
    glTranslatef(position2,0.0f, 0.0f);
    x=-0.8f; y=0.6f;radius =.1f;
    glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 255);
    glVertex2f(x, y);
    for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	// Cloud 2
	x=-0.6f; y=0.6f;radius =.17f;
    glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 255);
    glVertex2f(x, y);
    for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	// Cloud 3
	x=-0.4f; y=0.6f;radius =.1f;
    glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 255);
    glVertex2f(x, y);
    for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
    glLoadIdentity();

    // Cloud 1.2
    glTranslatef(0.5,0.2,0);
	x=-0.77f; y=0.6f;radius =.1f;
    glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 255);
    glVertex2f(x, y);
    for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	// Cloud 2.2
	glTranslatef(0.03,0.02,0);
	x=-0.6f; y=0.6f;radius =.16f;
    glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 255);
    glVertex2f(x, y);
    for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	// Cloud 3.2
	x=-0.4f; y=0.6f;radius =.1f;
    glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 255);
    glVertex2f(x, y);
    for(i = 0; i <= triangleAmount;i++) {
        			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
    glLoadIdentity();

	glFlush();  // Render now

}

void init() {
   glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
}

void display2() {

     glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
     glClear(GL_COLOR_BUFFER_BIT);


     //bulding

     glTranslatef(-0.3,-0.2, 0);
     glBegin(GL_QUADS);              // Each set of 4 vertices form a quad
	 glColor3f(1.0f, 0.0f, 1.0f); // Paste colour
	 glVertex2f(0.0f, 0.2f);    // x, y
	 glVertex2f(0.0f, 0.4f);    // x, y
     glVertex2f(0.4f, 0.4f);
     glVertex2f(0.4f, 0.2f);
	 glEnd();
     glLoadIdentity();

     glTranslatef(-0.3,-0.2, 0);
     glBegin(GL_TRIANGLES);
     glColor3ub(204, 51, 0);  //Green
     glVertex2f(0.5f, 0.4f);
     glVertex2f(0.2f, 0.6f);
     glVertex2f(-0.1f, 0.4f);
     glEnd();
     glLoadIdentity();

     glTranslatef(-0.3,-0.2, 0);
     glBegin(GL_QUADS);              // Each set of 4 vertices form a quad
 	 glColor3f(1.0f, 1.0f, 1.0f); // White
     glVertex2f(0.225f, 0.2f);    // x, y
	 glVertex2f(0.225f, 0.3f);    // x, y
     glVertex2f(0.175f, 0.3f);
     glVertex2f(0.175f, 0.2f);
	 glEnd();


     //tree

     glLoadIdentity();
     glTranslatef(0.21, 0.5, 0.0);
     glBegin(GL_QUADS);
     glColor3ub(102, 34, 0);
     glVertex2f(-0.9f, -0.5f);
     glVertex2f(-0.9f, -0.1f);// x, y
     glVertex2f(-0.85f, -0.1f);
     glVertex2f(-.85f, -0.5f);// x, y
     glEnd();
     glLoadIdentity();

     glTranslatef(0.2, 0.5, 0.0);
     glBegin(GL_TRIANGLES);
     glColor3ub(0, 255, 0);
     glVertex2f(-1.1f, -0.1f);
     glVertex2f(-0.85f, 0.1f);// x, y
     glVertex2f(-0.6f, -0.1f);
     glEnd();
     glLoadIdentity();

     glTranslatef(0.2, 0.5, 0.0);
     glBegin(GL_TRIANGLES);
     glColor3ub(0, 255, 0);
     glVertex2f(-1.1f, -0.2f);
     glVertex2f(-0.85f, 0.0f);// x, y
     glVertex2f(-0.6f, -0.2f);
     glEnd();


     //Roads

     glLoadIdentity();
     glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	 glColor3ub(1.0f, 1.0f, 1.0f); // White
	 glVertex2f(-1.0f, -0.6f);    // x, y
	 glVertex2f(0.0f, -0.6f);    // x, y
	 glVertex2f(0.0f, -0.6f);    // x, y
	 glVertex2f(1.0f, -0.6f);    // x, y

	 glEnd();

     glBegin(GL_QUADS);
     glColor3ub(38, 38, 38);

     glVertex2f(-1.00f, -0.5f);
     glVertex2f(1.00f, -0.5f);// x, y
     glVertex2f(1.00f, -0.95f);
     glVertex2f(-1.00f, -0.95f);// x, y
     glEnd();


     glBegin(GL_QUADS);
     glColor3ub(255, 255, 255);

     glVertex2f(-0.7f, -0.65f);
     glVertex2f(-0.5f, -0.65f);// x, y
     glVertex2f(-0.5f, -0.75f);
     glVertex2f(-0.7f, -0.75f);// x, y
     glEnd();

     glBegin(GL_QUADS);
     glColor3ub(255, 255, 255);

     glVertex2f(-0.99f, -0.65f);
     glVertex2f(-0.9f, -0.65f);// x, y
     glVertex2f(-0.9f, -0.75f);
     glVertex2f(-0.99f, -0.75f);// x, y
     glEnd();

     glBegin(GL_QUADS);
     glColor3ub(255, 255, 255);

     glVertex2f(-0.3f, -0.65f);
     glVertex2f(-0.1f, -0.65f);// x, y
     glVertex2f(-0.1f, -0.75f);
     glVertex2f(-0.3f, -0.75f);// x, y
     glEnd();

     glBegin(GL_QUADS);
     glColor3ub(255, 255, 255);

     glVertex2f(0.1f, -0.65f);
     glVertex2f(0.3f, -0.65f);// x, y
     glVertex2f(0.3f, -0.75f);
     glVertex2f(0.1f, -0.75f);// x, y
     glEnd();

     glBegin(GL_QUADS);
     glColor3ub(255, 255, 255);

     glVertex2f(0.5f, -0.65f);
     glVertex2f(0.7f, -0.65f);// x, y
     glVertex2f(0.7f, -0.75f);
     glVertex2f(0.5f, -0.75f);// x, y
     glEnd();

     glBegin(GL_QUADS);
     glColor3ub(245, 245, 245);

     glVertex2f(0.9f, -0.65f);
     glVertex2f(0.99f, -0.65f);// x, y
     glVertex2f(0.99f, -0.75f);
     glVertex2f(0.9f, -0.75f);// x, y
     glEnd();


     ////plane***********

     glPushMatrix();
     glTranslatef(position1,0.0f, 0.0f);
     glBegin(GL_QUADS);
     glColor3ub(245, 245, 245);

     glVertex2f(-0.7f, -0.35f);
     glVertex2f(0.2f, -0.35f);// x, y
     glVertex2f(0.2f, -0.55f);
     glVertex2f(-0.7f, -0.55f);// x, y
     glEnd();

     glBegin(GL_TRIANGLES);
     glColor3ub(245, 245, 245);

     glVertex2f(0.2f, -0.35f);
     glVertex2f(0.4f, -0.55f);// x, y
     glVertex2f(0.2f, -0.55f);
     glEnd();

     glBegin(GL_TRIANGLES);
     glColor3ub(245, 245, 245);

     glVertex2f(-0.7f, -0.45f);
     glVertex2f(-0.55f, -0.35f);// x, y
     glVertex2f(-0.7f, -0.15f);
     glEnd();

     glBegin(GL_TRIANGLES);
     glColor3ub(245, 245, 245);

     glVertex2f(-0.2f, -0.45f);
     glVertex2f(0.0f, -0.35f);// x, y
     glVertex2f(-0.2f, -0.15f);
     glEnd();


	 GLfloat x=-.5f; GLfloat y=-.6f; GLfloat radius =.05f;
	 int triangleAmount = 30; //# of triangles used to draw circle

	  //GLfloat radius = 0.8f; //radius
	 GLfloat twicePi = 2.0f * PI;

     glBegin(GL_TRIANGLE_FAN);
	 glColor3ub(0,0,255);
     glVertex2f(x, y); // center of circle
     for(i = 0; i <= triangleAmount;i++)
            {
			glVertex2f(x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount)));
		    }
	 glEnd();

	 x=0.25f; y=-0.6f;radius =0.05f;
     glBegin(GL_TRIANGLE_FAN);
	 glColor3ub(0,0,255);
     glVertex2f(x, y); // center of circle
     for(i = 0; i <= triangleAmount;i++)
            {
			glVertex2f(x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount)));
		    }

	 glEnd();

     x=0.15f; y=-0.45f;radius =0.02f;
     glBegin(GL_TRIANGLE_FAN);
	 glColor3ub(0,51,0);
     glVertex2f(x, y); // center of circle
     for(i = 0; i <= triangleAmount;i++)
            {
			glVertex2f(x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount)));
		    }

	 glEnd();

     x=-0.15f; y=-0.45f;radius =0.02f;
     glBegin(GL_TRIANGLE_FAN);
	 glColor3ub(0,51,0);
     glVertex2f(x, y); // center of circle
     for(i = 0; i <= triangleAmount;i++)
            {
			glVertex2f(x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount)));
		    }
	 glEnd();

     x=-.35f; y=-.45f;radius =.02f;
     glBegin(GL_TRIANGLE_FAN);
	 glColor3ub(0,51,0);
     glVertex2f(x, y); // center of circle
     for(i = 0; i <= triangleAmount;i++)
            {
			glVertex2f(x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount)));
		    }
	 glEnd();

     x=-.45f; y=-.45f;radius =.02f;
     glBegin(GL_TRIANGLE_FAN);
	 glColor3ub(0,51,0);
     glVertex2f(x, y); // center of circle
     for(i = 0; i <= triangleAmount;i++)
            {
			glVertex2f(x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount)));
		    }
	glEnd();

    glPopMatrix();


    //-----Windmill-------

    glTranslatef(1.0, 0.5, 0);
    glBegin(GL_QUADS);
    glColor3ub(204, 51, 0);
    glVertex2f(-0.55f, -0.5f);
    glVertex2f( -0.45f, -0.5f);
    glVertex2f( -0.47f, 0.06f);
    glVertex2f( -0.53f, 0.06f);
    glEnd();

    glPushMatrix();
    glTranslatef(-0.5, 0.06,0);
    glRotatef(j,0,0.0,0.1);//i=how many degree you want to rotate around an axis
    glBegin(GL_TRIANGLES);
    glColor3ub(235, 235, 224);//Blade
    glVertex2f(0.0f, 0.0f);
    glVertex2f( 0.05f, 0.3f);
    glVertex2f( -0.05f, 0.3f);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(235, 235, 224);//Blade
    glVertex2f(0.0f, 0.0f);
    glVertex2f( -0.05f, -0.3f);
    glVertex2f( 0.05f, -0.3f);
    glEnd();

    glPopMatrix();

    j-= 0.1f; //clock wise

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0, 0, 0);
    glVertex2f(x, y); //windmill holding
    for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
    glEnd();
    glLoadIdentity();

    //Clouds==================

    // Cloud 1
    glTranslatef(position2,0.0f, 0.0f);
    x=-0.8f; y=0.6f;radius =.1f;
    glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 255);
    glVertex2f(x, y);
    for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	// Cloud 2
	x=-0.6f; y=0.6f;radius =.17f;
    glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 255);
    glVertex2f(x, y);
    for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	// Cloud 3
	x=-0.4f; y=0.6f;radius =.1f;
    glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 255);
    glVertex2f(x, y);
    for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
    glLoadIdentity();

    // Cloud 1.2
    glTranslatef(0.5,0.2,0);
	x=-0.77f; y=0.6f;radius =.1f;
    glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 255);
    glVertex2f(x, y);
    for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	// Cloud 2.2
	glTranslatef(0.03,0.02,0);
	x=-0.6f; y=0.6f;radius =.16f;
    glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 255);
    glVertex2f(x, y);
    for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	// Cloud 3.2
	x=-0.4f; y=0.6f;radius =.1f;
    glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 255);
    glVertex2f(x, y);
    for(i = 0; i <= triangleAmount;i++) {
        			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
    glLoadIdentity();


    //Rain
   glPushMatrix();
   glTranslatef(0.0f,Rainposition, 0.0f);

   glBegin(GL_LINES);
   glColor3f(1.0f, 1.0f, 1.0f);

   glVertex2f(-1.0f,0.0f);
   glVertex2f(-1.0f,0.1f);
   glVertex2f(-1.0f,0.2f);
   glVertex2f(-1.0f,0.3f);
   glVertex2f(-1.0f,0.4f);
   glVertex2f(-1.0f,0.5f);
   glVertex2f(-1.0f,0.6f);
   glVertex2f(-1.0f,0.7f);
   glVertex2f(-1.0f,0.8f);
   glVertex2f(-1.0f,0.9f);
   glVertex2f(-0.9f,0.0f);
   glVertex2f(-0.9f,0.1f);
   glVertex2f(-0.9f,0.2f);
   glVertex2f(-0.9f,0.3f);
   glVertex2f(-0.9f,0.4f);
   glVertex2f(-0.9f,0.5f);
   glVertex2f(-0.9f,0.6f);
   glVertex2f(-0.9f,0.7f);
   glVertex2f(-0.9f,0.8f);
   glVertex2f(-0.9f,0.9f);
   glVertex2f(-0.8f,0.0f);
   glVertex2f(-0.8f,0.1f);
   glVertex2f(-0.8f,0.2f);
   glVertex2f(-0.8f,0.3f);
   glVertex2f(-0.8f,0.4f);
   glVertex2f(-0.8f,0.5f);
   glVertex2f(-0.8f,0.6f);
   glVertex2f(-0.8f,0.7f);
   glVertex2f(-0.8f,0.8f);
   glVertex2f(-0.8f,0.9f);
   glVertex2f(-0.7f,0.0f);
   glVertex2f(-0.7f,0.1f);
   glVertex2f(-0.7f,0.2f);
   glVertex2f(-0.7f,0.3f);
   glVertex2f(-0.7f,0.4f);
   glVertex2f(-0.7f,0.5f);
   glVertex2f(-0.7f,0.6f);
   glVertex2f(-0.7f,0.7f);
   glVertex2f(-0.7f,0.8f);
   glVertex2f(-0.7f,0.9f);
   glVertex2f(-0.6f,0.0f);
   glVertex2f(-0.6f,0.1f);
   glVertex2f(-0.6f,0.2f);
   glVertex2f(-0.6f,0.3f);
   glVertex2f(-0.6f,0.4f);
   glVertex2f(-0.6f,0.5f);
   glVertex2f(-0.6f,0.6f);
   glVertex2f(-0.6f,0.7f);
   glVertex2f(-0.6f,0.8f);
   glVertex2f(-0.6f,0.9f);
   glVertex2f(-0.5f,0.0f);
   glVertex2f(-0.5f,0.1f);
   glVertex2f(-0.5f,0.2f);
   glVertex2f(-0.5f,0.3f);
   glVertex2f(-0.5f,0.4f);
   glVertex2f(-0.5f,0.5f);
   glVertex2f(-0.5f,0.6f);
   glVertex2f(-0.5f,0.7f);
   glVertex2f(-0.5f,0.8f);
   glVertex2f(-0.5f,0.9f);
   glVertex2f(-0.4f,0.0f);
   glVertex2f(-0.4f,0.1f);
   glVertex2f(-0.4f,0.2f);
   glVertex2f(-0.4f,0.3f);
   glVertex2f(-0.4f,0.4f);
   glVertex2f(-0.4f,0.5f);
   glVertex2f(-0.4f,0.6f);
   glVertex2f(-0.4f,0.7f);
   glVertex2f(-0.4f,0.8f);
   glVertex2f(-0.4f,0.9f);
   glVertex2f(-0.3f,0.0f);
   glVertex2f(-0.3f,0.1f);
   glVertex2f(-0.3f,0.2f);
   glVertex2f(-0.3f,0.3f);
   glVertex2f(-0.3f,0.4f);
   glVertex2f(-0.3f,0.5f);
   glVertex2f(-0.3f,0.6f);
   glVertex2f(-0.3f,0.7f);
   glVertex2f(-0.3f,0.8f);
   glVertex2f(-0.3f,0.9f);
   glVertex2f(-0.2f,0.0f);
   glVertex2f(-0.2f,0.1f);
   glVertex2f(-0.2f,0.2f);
   glVertex2f(-0.2f,0.3f);
   glVertex2f(-0.2f,0.4f);
   glVertex2f(-0.2f,0.5f);
   glVertex2f(-0.2f,0.6f);
   glVertex2f(-0.2f,0.7f);
   glVertex2f(-0.2f,0.8f);
   glVertex2f(-0.2f,0.9f);
   glVertex2f(-0.1f,0.0f);
   glVertex2f(-0.1f,0.1f);
   glVertex2f(-0.1f,0.2f);
   glVertex2f(-0.1f,0.3f);
   glVertex2f(-0.1f,0.4f);
   glVertex2f(-0.1f,0.5f);
   glVertex2f(-0.1f,0.6f);
   glVertex2f(-0.1f,0.7f);
   glVertex2f(-0.1f,0.8f);
   glVertex2f(-0.1f,0.9f);
   glVertex2f(0.0f,0.0f);
   glVertex2f(0.0f,0.1f);
   glVertex2f(0.0f,0.2f);
   glVertex2f(0.0f,0.3f);
   glVertex2f(0.0f,0.4f);
   glVertex2f(0.0f,0.5f);
   glVertex2f(0.0f,0.6f);
   glVertex2f(0.0f,0.7f);
   glVertex2f(0.0f,0.8f);
   glVertex2f(0.0f,0.9f);
   glVertex2f(0.1f,0.0f);
   glVertex2f(0.1f,0.1f);
   glVertex2f(0.1f,0.2f);
   glVertex2f(0.1f,0.3f);
   glVertex2f(0.1f,0.4f);
   glVertex2f(0.1f,0.5f);
   glVertex2f(0.1f,0.6f);
   glVertex2f(0.1f,0.7f);
   glVertex2f(0.1f,0.8f);
   glVertex2f(0.1f,0.9f);
   glVertex2f(0.20f,0.0f);
   glVertex2f(0.20f,0.1f);
   glVertex2f(0.20f,0.2f);
   glVertex2f(0.20f,0.3f);
   glVertex2f(0.20f,0.4f);
   glVertex2f(0.20f,0.5f);
   glVertex2f(0.20f,0.6f);
   glVertex2f(0.20f,0.7f);
   glVertex2f(0.20f,0.8f);
   glVertex2f(0.20f,0.9f);
   glVertex2f(0.30f,0.0f);
   glVertex2f(0.30f,0.1f);
   glVertex2f(0.30f,0.2f);
   glVertex2f(0.30f,0.3f);
   glVertex2f(0.30f,0.4f);
   glVertex2f(0.30f,0.5f);
   glVertex2f(0.30f,0.6f);
   glVertex2f(0.30f,0.7f);
   glVertex2f(0.30f,0.8f);
   glVertex2f(0.30f,0.9f);
   glVertex2f(0.40f,0.0f);
   glVertex2f(0.40f, 0.1f);
   glVertex2f(0.40f,0.2f);
   glVertex2f(0.40f, 0.3f);
   glVertex2f(0.40f,0.4f);
   glVertex2f(0.40f, 0.5f);
   glVertex2f(0.40f,0.6f);
   glVertex2f(0.40f, 0.7f);
   glVertex2f(0.40f,0.8f);
   glVertex2f(0.40f, 0.9f);
   glVertex2f(0.50f,0.0f);
   glVertex2f(0.50f,0.1f);
   glVertex2f(0.50f,0.2f);
   glVertex2f(0.50f,0.3f);
   glVertex2f(0.50f,0.4f);
   glVertex2f(0.50f,0.5f);
   glVertex2f(0.50f,0.6f);
   glVertex2f(0.50f,0.7f);
   glVertex2f(0.50f,0.8f);
   glVertex2f(0.50f,0.9f);
   glVertex2f(0.60f,0.0f);
   glVertex2f(0.60f,0.1f);
   glVertex2f(0.60f,0.2f);
   glVertex2f(0.60f,0.3f);
   glVertex2f(0.60f,0.4f);
   glVertex2f(0.60f,0.5f);
   glVertex2f(0.60f,0.6f);
   glVertex2f(0.60f,0.7f);
   glVertex2f(0.60f,0.8f);
   glVertex2f(0.60f,0.9f);
   glVertex2f(0.70f,0.0f);
   glVertex2f(0.70f,0.1f);
   glVertex2f(0.70f,0.2f);
   glVertex2f(0.70f,0.3f);
   glVertex2f(0.70f,0.4f);
   glVertex2f(0.70f,0.5f);
   glVertex2f(0.70f,0.6f);
   glVertex2f(0.70f,0.7f);
   glVertex2f(0.70f,0.8f);
   glVertex2f(0.70f,0.9f);
   glVertex2f(0.80f,0.0f);
   glVertex2f(0.80f, 0.1f);
   glVertex2f(0.80f,0.2f);
   glVertex2f(0.80f, 0.3f);
   glVertex2f(0.80f,0.4f);
   glVertex2f(0.80f, 0.5f);
   glVertex2f(0.80f,0.6f);
   glVertex2f(0.80f,0.7f);
   glVertex2f(0.80f,0.8f);
   glVertex2f(0.80f,0.9f);
   glVertex2f(0.90f,0.0f);
   glVertex2f(0.90f,0.1f);
   glVertex2f(0.90f,0.2f);
   glVertex2f(0.90f,0.3f);
   glVertex2f(0.90f,0.4f);
   glVertex2f(0.90f,0.5f);
   glVertex2f(0.90f,0.6f);
   glVertex2f(0.90f,0.7f);
   glVertex2f(0.90f,0.8f);
   glVertex2f(0.90f,0.9f);


   glVertex2f(-1.0f,-0.1f);
   glVertex2f(-1.0f,-0.2f);
   glVertex2f(-1.0f,-0.3f);
   glVertex2f(-1.0f,-0.4f);
   glVertex2f(-1.0f,-0.5f);
   glVertex2f(-1.0f,-0.6f);
   glVertex2f(-1.0f,-0.7f);
   glVertex2f(-1.0f,-0.8f);
   glVertex2f(-1.0f,-1.0f);
   glVertex2f(-1.0f,-0.9f);
   glVertex2f(-0.9f,-0.1f);
   glVertex2f(-0.9f,-0.2f);
   glVertex2f(-0.9f,-0.3f);
   glVertex2f(-0.9f,-0.4f);
   glVertex2f(-0.9f,-0.5f);
   glVertex2f(-0.9f,-0.6f);
   glVertex2f(-0.9f,-0.7f);
   glVertex2f(-0.9f,-0.8f);
   glVertex2f(-0.9f,-0.9f);
   glVertex2f(-0.9f,-1.0f);
   glVertex2f(-0.8f,-0.1f);
   glVertex2f(-0.8f,-0.2f);
   glVertex2f(-0.8f,-0.3f);
   glVertex2f(-0.8f,-0.4f);
   glVertex2f(-0.8f,-0.5f);
   glVertex2f(-0.8f,-0.6f);
   glVertex2f(-0.8f,-0.7f);
   glVertex2f(-0.8f,-0.8f);
   glVertex2f(-0.8f,-0.9f);
   glVertex2f(-0.8f,-1.0f);
   glVertex2f(-0.7f,-0.1f);
   glVertex2f(-0.7f,-0.2f);
   glVertex2f(-0.7f,-0.3f);
   glVertex2f(-0.7f,-0.4f);
   glVertex2f(-0.7f,-0.5f);
   glVertex2f(-0.7f,-0.6f);
   glVertex2f(-0.7f,-0.7f);
   glVertex2f(-0.7f,-0.8f);
   glVertex2f(-0.7f,-0.9f);
   glVertex2f(-0.7f,-1.0f);
   glVertex2f(-0.6f,-0.1f);
   glVertex2f(-0.6f,-0.2f);
   glVertex2f(-0.6f,-0.3f);
   glVertex2f(-0.6f,-0.4f);
   glVertex2f(-0.6f,-0.5f);
   glVertex2f(-0.6f,-0.6f);
   glVertex2f(-0.6f,-0.7f);
   glVertex2f(-0.6f,-0.8f);
   glVertex2f(-0.6f,-0.9f);
   glVertex2f(-0.6f,-1.0f);
   glVertex2f(-0.5f,-0.1f);
   glVertex2f(-0.5f,-0.2f);
   glVertex2f(-0.5f,-0.3f);
   glVertex2f(-0.5f,-0.4f);
   glVertex2f(-0.5f,-0.5f);
   glVertex2f(-0.5f,-0.6f);
   glVertex2f(-0.5f,-0.7f);
   glVertex2f(-0.5f,-0.8f);
   glVertex2f(-0.5f,-0.9f);
   glVertex2f(-0.5f,-1.0f);
   glVertex2f(-0.4f,-0.1f);
   glVertex2f(-0.4f,-0.2f);
   glVertex2f(-0.4f,-0.3f);
   glVertex2f(-0.4f,-0.4f);
   glVertex2f(-0.4f,-0.5f);
   glVertex2f(-0.4f,-0.6f);
   glVertex2f(-0.4f,-0.7f);
   glVertex2f(-0.4f,-0.8f);
   glVertex2f(-0.4f,-0.9f);
   glVertex2f(-0.4f,-1.0f);
   glVertex2f(-0.3f,-0.1f);
   glVertex2f(-0.3f,-0.2f);
   glVertex2f(-0.3f,-0.3f);
   glVertex2f(-0.3f,-0.4f);
   glVertex2f(-0.3f,-0.5f);
   glVertex2f(-0.3f,-0.6f);
   glVertex2f(-0.3f,-0.7f);
   glVertex2f(-0.3f,-0.8f);
   glVertex2f(-0.3f,-0.9f);
   glVertex2f(-0.3f,-1.0f);
   glVertex2f(-0.2f,-0.1f);
   glVertex2f(-0.2f,-0.2f);
   glVertex2f(-0.2f,-0.3f);
   glVertex2f(-0.2f,-0.4f);
   glVertex2f(-0.2f,-0.5f);
   glVertex2f(-0.2f,-0.6f);
   glVertex2f(-0.2f,-0.7f);
   glVertex2f(-0.2f,-0.8f);
   glVertex2f(-0.2f,-0.9f);
   glVertex2f(-0.2f,-1.0f);
   glVertex2f(-0.1f,-0.1f);
   glVertex2f(-0.1f,-0.2f);
   glVertex2f(-0.1f,-0.3f);
   glVertex2f(-0.1f,-0.4f);
   glVertex2f(-0.1f,-0.5f);
   glVertex2f(-0.1f,-0.6f);
   glVertex2f(-0.1f,-0.7f);
   glVertex2f(-0.1f,-0.8f);
   glVertex2f(-0.1f,-0.9f);
   glVertex2f(-0.1f,-1.0f);
   glVertex2f(0.0f,-0.1f);
   glVertex2f(0.0f,-0.2f);
   glVertex2f(0.0f,-0.3f);
   glVertex2f(0.0f,-0.4f);
   glVertex2f(0.0f,-0.5f);
   glVertex2f(0.0f,-0.6f);
   glVertex2f(0.0f,-0.7f);
   glVertex2f(0.0f,-0.8f);
   glVertex2f(0.0f,-0.9f);
   glVertex2f(0.0f,-1.0f);
   glVertex2f(0.1f,-0.1f);
   glVertex2f(0.1f,-0.2f);
   glVertex2f(0.1f,-0.3f);
   glVertex2f(0.1f,-0.4f);
   glVertex2f(0.1f,-0.5f);
   glVertex2f(0.1f,-0.6f);
   glVertex2f(0.1f,-0.7f);
   glVertex2f(0.1f,-0.8f);
   glVertex2f(0.1f,-0.9f);
   glVertex2f(0.1f,-1.0f);
   glVertex2f(0.20f,-0.1f);
   glVertex2f(0.20f,-0.2f);
   glVertex2f(0.20f,-0.3f);
   glVertex2f(0.20f,-0.4f);
   glVertex2f(0.20f,-0.5f);
   glVertex2f(0.20f,-0.6f);
   glVertex2f(0.20f,-0.7f);
   glVertex2f(0.20f,-0.8f);
   glVertex2f(0.20f,-0.9f);
   glVertex2f(0.20f,-1.0);
   glVertex2f(0.30f,-0.1f);
   glVertex2f(0.30f,-0.2f);
   glVertex2f(0.30f,-0.3f);
   glVertex2f(0.30f,-0.4f);
   glVertex2f(0.30f,-0.5f);
   glVertex2f(0.30f,-0.6f);
   glVertex2f(0.30f,-0.7f);
   glVertex2f(0.30f,-0.8f);
   glVertex2f(0.30f,-0.9f);
   glVertex2f(0.30f,-1.0f);
   glVertex2f(0.40f,-0.1f);
   glVertex2f(0.40f,-0.2f);
   glVertex2f(0.40f,-0.3f);
   glVertex2f(0.40f,-0.4f);
   glVertex2f(0.40f,-0.5f);
   glVertex2f(0.40f,-0.6f);
   glVertex2f(0.40f,-0.7f);
   glVertex2f(0.40f,-0.8f);
   glVertex2f(0.40f,-0.9f);
   glVertex2f(0.40f,-1.0f);
   glVertex2f(0.50f,-0.1f);
   glVertex2f(0.50f,-0.2f);
   glVertex2f(0.50f,-0.3f);
   glVertex2f(0.50f,-0.4f);
   glVertex2f(0.50f,-0.5f);
   glVertex2f(0.50f,-0.6f);
   glVertex2f(0.50f,-0.7f);
   glVertex2f(0.50f,-0.8f);
   glVertex2f(0.50f,-0.9f);
   glVertex2f(0.50f,-1.0f);
   glVertex2f(0.60f,-0.1f);
   glVertex2f(0.60f,-0.2f);
   glVertex2f(0.60f,-0.3f);
   glVertex2f(0.60f,-0.4f);
   glVertex2f(0.60f,-0.5f);
   glVertex2f(0.60f,-0.6f);
   glVertex2f(0.60f,-0.7f);
   glVertex2f(0.60f,-0.8f);
   glVertex2f(0.60f,-0.9f);
   glVertex2f(0.60f,-1.0f);
   glVertex2f(0.70f,-0.1f);
   glVertex2f(0.70f,-0.2f);
   glVertex2f(0.70f,-0.3f);
   glVertex2f(0.70f,-0.4f);
   glVertex2f(0.70f,-0.5f);
   glVertex2f(0.70f,-0.6f);
   glVertex2f(0.70f,-0.7f);
   glVertex2f(0.70f,-0.8f);
   glVertex2f(0.70f,-0.9f);
   glVertex2f(0.70f,-1.0f);
   glVertex2f(0.80f,-0.1f);
   glVertex2f(0.80f,-0.2f);
   glVertex2f(0.80f,-0.3f);
   glVertex2f(0.80f,-0.4f);
   glVertex2f(0.80f,-0.5f);
   glVertex2f(0.80f,-0.6f);
   glVertex2f(0.80f,-0.7f);
   glVertex2f(0.80f,-0.8f);
   glVertex2f(0.80f,-0.9f);
   glVertex2f(0.80f,-1.0f);
   glVertex2f(0.90f,-0.1f);
   glVertex2f(0.90f,-0.2f);
   glVertex2f(0.90f,-0.3f);
   glVertex2f(0.90f,-0.4f);
   glVertex2f(0.90f,-0.5f);
   glVertex2f(0.90f,-0.6f);
   glVertex2f(0.90f,-0.7f);
   glVertex2f(0.90f,-0.8f);
   glVertex2f(0.90f,-0.9f);
   glVertex2f(0.90f,-1.0f);
   glEnd();

   glLoadIdentity();
   glPopMatrix();



   glFlush();
}



void handleKeypress(unsigned char key, int x, int y) {

	switch (key) {

case 'n':    //Rain & Night View

glutDisplayFunc(display2);
glutPostRedisplay();
break;

case 'd':    // Day View
glutDisplayFunc(display);
glutPostRedisplay();
break;
	}
}

////Main Function
int main(int argc, char** argv) {
	glutInit(&argc, argv);             // Initialize GLUT
	glutCreateWindow("Airport View with Rain"); // Create a window with the given title
	glutInitWindowSize(320, 320); // Set the window's initial width & height
	glutInitWindowPosition(50, 50);
	glutDisplayFunc(display); // Register display callback handler for window re-paint
	glutTimerFunc(100, update1,0);
	glutTimerFunc(100, update2,0);
    glutIdleFunc(Idle); //glutIdleFunc sets the global idle callback to be func so a GLUT program can perform background processing tasks or continuous animation when window system events are not being received.

    init();
    glutKeyboardFunc(handleKeypress);
    glutTimerFunc(100, Rain, 0);

	glutMainLoop();           // Enter the event-processing loop
	return 0;
}
