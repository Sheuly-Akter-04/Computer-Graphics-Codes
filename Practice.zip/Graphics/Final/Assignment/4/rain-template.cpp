#include <windows.h>  // for MS Windows
#include <GL/gl.h>
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include<math.h>>
#include<cstdio>
# define PI  3.14159265358979323846
GLfloat j = 0.0f;

void Idle()
{
    glutPostRedisplay();//// marks the current window as needing to be redisplayed
}
//Write to other function



GLfloat Rainposition = 0.0f;
GLfloat RainSpeed = 0.06f;

void Rain(int value) {

    if(Rainposition <0.0)
        Rainposition = 0.2f;

    Rainposition -= RainSpeed;

	glutPostRedisplay();


	glutTimerFunc(100, Rain, 0);
}


void display() {
   glClear(GL_COLOR_BUFFER_BIT);
   glLoadIdentity();

  //write your airport view display code with out Rain

glFlush();
}


void init() {
   glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
}

void display2() {
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
   glClear(GL_COLOR_BUFFER_BIT);

//Write your airport view code

//Rain
glPushMatrix();
glTranslatef(0.0f,Rainposition, 0.0f);

glBegin(GL_LINES);
glColor3f(1.0f, 1.0f, 1.0f);

   glVertex2f(-1.0f,0.0f);
   glVertex2f(-1.0f,0.1f);
   glVertex2f(-1.0f,0.2f);
   glVertex2f(-1.0f,0.3f);
   glVertex2f(-1.0f,0.4f);
   glVertex2f(-1.0f,0.5f);
   glVertex2f(-1.0f,0.6f);
   glVertex2f(-1.0f,0.7f);
   glVertex2f(-1.0f,0.8f);
   glVertex2f(-1.0f,0.9f);
   glVertex2f(-0.9f,0.0f);
   glVertex2f(-0.9f,0.1f);
   glVertex2f(-0.9f,0.2f);
   glVertex2f(-0.9f,0.3f);
   glVertex2f(-0.9f,0.4f);
   glVertex2f(-0.9f,0.5f);
   glVertex2f(-0.9f,0.6f);
   glVertex2f(-0.9f,0.7f);
   glVertex2f(-0.9f,0.8f);
   glVertex2f(-0.9f,0.9f);
   glVertex2f(-0.8f,0.0f);
   glVertex2f(-0.8f,0.1f);
   glVertex2f(-0.8f,0.2f);
   glVertex2f(-0.8f,0.3f);
   glVertex2f(-0.8f,0.4f);
   glVertex2f(-0.8f,0.5f);
   glVertex2f(-0.8f,0.6f);
   glVertex2f(-0.8f,0.7f);
   glVertex2f(-0.8f,0.8f);
   glVertex2f(-0.8f,0.9f);
   glVertex2f(-0.7f,0.0f);
   glVertex2f(-0.7f,0.1f);
   glVertex2f(-0.7f,0.2f);
   glVertex2f(-0.7f,0.3f);
   glVertex2f(-0.7f,0.4f);
   glVertex2f(-0.7f,0.5f);
   glVertex2f(-0.7f,0.6f);
   glVertex2f(-0.7f,0.7f);
   glVertex2f(-0.7f,0.8f);
   glVertex2f(-0.7f,0.9f);
   glVertex2f(-0.6f,0.0f);
   glVertex2f(-0.6f,0.1f);
   glVertex2f(-0.6f,0.2f);
   glVertex2f(-0.6f,0.3f);
   glVertex2f(-0.6f,0.4f);
   glVertex2f(-0.6f,0.5f);
   glVertex2f(-0.6f,0.6f);
   glVertex2f(-0.6f,0.7f);
   glVertex2f(-0.6f,0.8f);
   glVertex2f(-0.6f,0.9f);
   glVertex2f(-0.5f,0.0f);
   glVertex2f(-0.5f,0.1f);
   glVertex2f(-0.5f,0.2f);
   glVertex2f(-0.5f,0.3f);
   glVertex2f(-0.5f,0.4f);
   glVertex2f(-0.5f,0.5f);
   glVertex2f(-0.5f,0.6f);
   glVertex2f(-0.5f,0.7f);
   glVertex2f(-0.5f,0.8f);
   glVertex2f(-0.5f,0.9f);
   glVertex2f(-0.4f,0.0f);
   glVertex2f(-0.4f,0.1f);
   glVertex2f(-0.4f,0.2f);
   glVertex2f(-0.4f,0.3f);
   glVertex2f(-0.4f,0.4f);
   glVertex2f(-0.4f,0.5f);
   glVertex2f(-0.4f,0.6f);
   glVertex2f(-0.4f,0.7f);
   glVertex2f(-0.4f,0.8f);
   glVertex2f(-0.4f,0.9f);
   glVertex2f(-0.3f,0.0f);
   glVertex2f(-0.3f,0.1f);
   glVertex2f(-0.3f,0.2f);
   glVertex2f(-0.3f,0.3f);
   glVertex2f(-0.3f,0.4f);
   glVertex2f(-0.3f,0.5f);
   glVertex2f(-0.3f,0.6f);
   glVertex2f(-0.3f,0.7f);
   glVertex2f(-0.3f,0.8f);
   glVertex2f(-0.3f,0.9f);
   glVertex2f(-0.2f,0.0f);
   glVertex2f(-0.2f,0.1f);
   glVertex2f(-0.2f,0.2f);
   glVertex2f(-0.2f,0.3f);
   glVertex2f(-0.2f,0.4f);
   glVertex2f(-0.2f,0.5f);
   glVertex2f(-0.2f,0.6f);
   glVertex2f(-0.2f,0.7f);
   glVertex2f(-0.2f,0.8f);
   glVertex2f(-0.2f,0.9f);
   glVertex2f(-0.1f,0.0f);
   glVertex2f(-0.1f,0.1f);
   glVertex2f(-0.1f,0.2f);
   glVertex2f(-0.1f,0.3f);
   glVertex2f(-0.1f,0.4f);
   glVertex2f(-0.1f,0.5f);
   glVertex2f(-0.1f,0.6f);
   glVertex2f(-0.1f,0.7f);
   glVertex2f(-0.1f,0.8f);
   glVertex2f(-0.1f,0.9f);
   glVertex2f(0.0f,0.0f);
   glVertex2f(0.0f,0.1f);
   glVertex2f(0.0f,0.2f);
   glVertex2f(0.0f,0.3f);
   glVertex2f(0.0f,0.4f);
   glVertex2f(0.0f,0.5f);
   glVertex2f(0.0f,0.6f);
   glVertex2f(0.0f,0.7f);
   glVertex2f(0.0f,0.8f);
   glVertex2f(0.0f,0.9f);
   glVertex2f(0.1f,0.0f);
   glVertex2f(0.1f,0.1f);
   glVertex2f(0.1f,0.2f);
   glVertex2f(0.1f,0.3f);
   glVertex2f(0.1f,0.4f);
   glVertex2f(0.1f,0.5f);
   glVertex2f(0.1f,0.6f);
   glVertex2f(0.1f,0.7f);
   glVertex2f(0.1f,0.8f);
   glVertex2f(0.1f,0.9f);
   glVertex2f(0.20f,0.0f);
   glVertex2f(0.20f,0.1f);
   glVertex2f(0.20f,0.2f);
   glVertex2f(0.20f,0.3f);
   glVertex2f(0.20f,0.4f);
   glVertex2f(0.20f,0.5f);
   glVertex2f(0.20f,0.6f);
   glVertex2f(0.20f,0.7f);
   glVertex2f(0.20f,0.8f);
   glVertex2f(0.20f,0.9f);
   glVertex2f(0.30f,0.0f);
   glVertex2f(0.30f,0.1f);
   glVertex2f(0.30f,0.2f);
   glVertex2f(0.30f,0.3f);
   glVertex2f(0.30f,0.4f);
   glVertex2f(0.30f,0.5f);
   glVertex2f(0.30f,0.6f);
   glVertex2f(0.30f,0.7f);
   glVertex2f(0.30f,0.8f);
   glVertex2f(0.30f,0.9f);
   glVertex2f(0.40f,0.0f);
   glVertex2f(0.40f, 0.1f);
   glVertex2f(0.40f,0.2f);
   glVertex2f(0.40f, 0.3f);
   glVertex2f(0.40f,0.4f);
   glVertex2f(0.40f, 0.5f);
   glVertex2f(0.40f,0.6f);
   glVertex2f(0.40f, 0.7f);
   glVertex2f(0.40f,0.8f);
   glVertex2f(0.40f, 0.9f);
   glVertex2f(0.50f,0.0f);
   glVertex2f(0.50f,0.1f);
   glVertex2f(0.50f,0.2f);
   glVertex2f(0.50f,0.3f);
   glVertex2f(0.50f,0.4f);
   glVertex2f(0.50f,0.5f);
   glVertex2f(0.50f,0.6f);
   glVertex2f(0.50f,0.7f);
   glVertex2f(0.50f,0.8f);
   glVertex2f(0.50f,0.9f);
   glVertex2f(0.60f,0.0f);
   glVertex2f(0.60f,0.1f);
   glVertex2f(0.60f,0.2f);
   glVertex2f(0.60f,0.3f);
   glVertex2f(0.60f,0.4f);
   glVertex2f(0.60f,0.5f);
   glVertex2f(0.60f,0.6f);
   glVertex2f(0.60f,0.7f);
   glVertex2f(0.60f,0.8f);
   glVertex2f(0.60f,0.9f);
   glVertex2f(0.70f,0.0f);
   glVertex2f(0.70f,0.1f);
   glVertex2f(0.70f,0.2f);
   glVertex2f(0.70f,0.3f);
   glVertex2f(0.70f,0.4f);
   glVertex2f(0.70f,0.5f);
   glVertex2f(0.70f,0.6f);
   glVertex2f(0.70f,0.7f);
   glVertex2f(0.70f,0.8f);
   glVertex2f(0.70f,0.9f);
   glVertex2f(0.80f,0.0f);
   glVertex2f(0.80f, 0.1f);
   glVertex2f(0.80f,0.2f);
   glVertex2f(0.80f, 0.3f);
   glVertex2f(0.80f,0.4f);
   glVertex2f(0.80f, 0.5f);
   glVertex2f(0.80f,0.6f);
   glVertex2f(0.80f,0.7f);
   glVertex2f(0.80f,0.8f);
   glVertex2f(0.80f,0.9f);
   glVertex2f(0.90f,0.0f);
   glVertex2f(0.90f,0.1f);
   glVertex2f(0.90f,0.2f);
   glVertex2f(0.90f,0.3f);
   glVertex2f(0.90f,0.4f);
   glVertex2f(0.90f,0.5f);
   glVertex2f(0.90f,0.6f);
   glVertex2f(0.90f,0.7f);
   glVertex2f(0.90f,0.8f);
   glVertex2f(0.90f,0.9f);


   glVertex2f(-1.0f,-0.1f);
   glVertex2f(-1.0f,-0.2f);
   glVertex2f(-1.0f,-0.3f);
   glVertex2f(-1.0f,-0.4f);
   glVertex2f(-1.0f,-0.5f);
   glVertex2f(-1.0f,-0.6f);
   glVertex2f(-1.0f,-0.7f);
   glVertex2f(-1.0f,-0.8f);
   glVertex2f(-1.0f,-1.0f);
   glVertex2f(-1.0f,-0.9f);
   glVertex2f(-0.9f,-0.1f);
   glVertex2f(-0.9f,-0.2f);
   glVertex2f(-0.9f,-0.3f);
   glVertex2f(-0.9f,-0.4f);
   glVertex2f(-0.9f,-0.5f);
   glVertex2f(-0.9f,-0.6f);
   glVertex2f(-0.9f,-0.7f);
   glVertex2f(-0.9f,-0.8f);
   glVertex2f(-0.9f,-0.9f);
   glVertex2f(-0.9f,-1.0f);
   glVertex2f(-0.8f,-0.1f);
   glVertex2f(-0.8f,-0.2f);
   glVertex2f(-0.8f,-0.3f);
   glVertex2f(-0.8f,-0.4f);
   glVertex2f(-0.8f,-0.5f);
   glVertex2f(-0.8f,-0.6f);
   glVertex2f(-0.8f,-0.7f);
   glVertex2f(-0.8f,-0.8f);
   glVertex2f(-0.8f,-0.9f);
   glVertex2f(-0.8f,-1.0f);
   glVertex2f(-0.7f,-0.1f);
   glVertex2f(-0.7f,-0.2f);
   glVertex2f(-0.7f,-0.3f);
   glVertex2f(-0.7f,-0.4f);
   glVertex2f(-0.7f,-0.5f);
   glVertex2f(-0.7f,-0.6f);
   glVertex2f(-0.7f,-0.7f);
   glVertex2f(-0.7f,-0.8f);
   glVertex2f(-0.7f,-0.9f);
   glVertex2f(-0.7f,-1.0f);
   glVertex2f(-0.6f,-0.1f);
   glVertex2f(-0.6f,-0.2f);
   glVertex2f(-0.6f,-0.3f);
   glVertex2f(-0.6f,-0.4f);
   glVertex2f(-0.6f,-0.5f);
   glVertex2f(-0.6f,-0.6f);
   glVertex2f(-0.6f,-0.7f);
   glVertex2f(-0.6f,-0.8f);
   glVertex2f(-0.6f,-0.9f);
   glVertex2f(-0.6f,-1.0f);
   glVertex2f(-0.5f,-0.1f);
   glVertex2f(-0.5f,-0.2f);
   glVertex2f(-0.5f,-0.3f);
   glVertex2f(-0.5f,-0.4f);
   glVertex2f(-0.5f,-0.5f);
   glVertex2f(-0.5f,-0.6f);
   glVertex2f(-0.5f,-0.7f);
   glVertex2f(-0.5f,-0.8f);
   glVertex2f(-0.5f,-0.9f);
   glVertex2f(-0.5f,-1.0f);
   glVertex2f(-0.4f,-0.1f);
   glVertex2f(-0.4f,-0.2f);
   glVertex2f(-0.4f,-0.3f);
   glVertex2f(-0.4f,-0.4f);
   glVertex2f(-0.4f,-0.5f);
   glVertex2f(-0.4f,-0.6f);
   glVertex2f(-0.4f,-0.7f);
   glVertex2f(-0.4f,-0.8f);
   glVertex2f(-0.4f,-0.9f);
   glVertex2f(-0.4f,-1.0f);
   glVertex2f(-0.3f,-0.1f);
   glVertex2f(-0.3f,-0.2f);
   glVertex2f(-0.3f,-0.3f);
   glVertex2f(-0.3f,-0.4f);
   glVertex2f(-0.3f,-0.5f);
   glVertex2f(-0.3f,-0.6f);
   glVertex2f(-0.3f,-0.7f);
   glVertex2f(-0.3f,-0.8f);
   glVertex2f(-0.3f,-0.9f);
   glVertex2f(-0.3f,-1.0f);
   glVertex2f(-0.2f,-0.1f);
   glVertex2f(-0.2f,-0.2f);
   glVertex2f(-0.2f,-0.3f);
   glVertex2f(-0.2f,-0.4f);
   glVertex2f(-0.2f,-0.5f);
   glVertex2f(-0.2f,-0.6f);
   glVertex2f(-0.2f,-0.7f);
   glVertex2f(-0.2f,-0.8f);
   glVertex2f(-0.2f,-0.9f);
   glVertex2f(-0.2f,-1.0f);
   glVertex2f(-0.1f,-0.1f);
   glVertex2f(-0.1f,-0.2f);
   glVertex2f(-0.1f,-0.3f);
   glVertex2f(-0.1f,-0.4f);
   glVertex2f(-0.1f,-0.5f);
   glVertex2f(-0.1f,-0.6f);
   glVertex2f(-0.1f,-0.7f);
   glVertex2f(-0.1f,-0.8f);
   glVertex2f(-0.1f,-0.9f);
   glVertex2f(-0.1f,-1.0f);
   glVertex2f(0.0f,-0.1f);
   glVertex2f(0.0f,-0.2f);
   glVertex2f(0.0f,-0.3f);
   glVertex2f(0.0f,-0.4f);
   glVertex2f(0.0f,-0.5f);
   glVertex2f(0.0f,-0.6f);
   glVertex2f(0.0f,-0.7f);
   glVertex2f(0.0f,-0.8f);
   glVertex2f(0.0f,-0.9f);
   glVertex2f(0.0f,-1.0f);
   glVertex2f(0.1f,-0.1f);
   glVertex2f(0.1f,-0.2f);
   glVertex2f(0.1f,-0.3f);
   glVertex2f(0.1f,-0.4f);
   glVertex2f(0.1f,-0.5f);
   glVertex2f(0.1f,-0.6f);
   glVertex2f(0.1f,-0.7f);
   glVertex2f(0.1f,-0.8f);
   glVertex2f(0.1f,-0.9f);
   glVertex2f(0.1f,-1.0f);
   glVertex2f(0.20f,-0.1f);
   glVertex2f(0.20f,-0.2f);
   glVertex2f(0.20f,-0.3f);
   glVertex2f(0.20f,-0.4f);
   glVertex2f(0.20f,-0.5f);
   glVertex2f(0.20f,-0.6f);
   glVertex2f(0.20f,-0.7f);
   glVertex2f(0.20f,-0.8f);
   glVertex2f(0.20f,-0.9f);
   glVertex2f(0.20f,-1.0);
   glVertex2f(0.30f,-0.1f);
   glVertex2f(0.30f,-0.2f);
   glVertex2f(0.30f,-0.3f);
   glVertex2f(0.30f,-0.4f);
   glVertex2f(0.30f,-0.5f);
   glVertex2f(0.30f,-0.6f);
   glVertex2f(0.30f,-0.7f);
   glVertex2f(0.30f,-0.8f);
   glVertex2f(0.30f,-0.9f);
   glVertex2f(0.30f,-1.0f);
   glVertex2f(0.40f,-0.1f);
   glVertex2f(0.40f,-0.2f);
   glVertex2f(0.40f,-0.3f);
   glVertex2f(0.40f,-0.4f);
   glVertex2f(0.40f,-0.5f);
   glVertex2f(0.40f,-0.6f);
   glVertex2f(0.40f,-0.7f);
   glVertex2f(0.40f,-0.8f);
   glVertex2f(0.40f,-0.9f);
   glVertex2f(0.40f,-1.0f);
   glVertex2f(0.50f,-0.1f);
   glVertex2f(0.50f,-0.2f);
   glVertex2f(0.50f,-0.3f);
   glVertex2f(0.50f,-0.4f);
   glVertex2f(0.50f,-0.5f);
   glVertex2f(0.50f,-0.6f);
   glVertex2f(0.50f,-0.7f);
   glVertex2f(0.50f,-0.8f);
   glVertex2f(0.50f,-0.9f);
   glVertex2f(0.50f,-1.0f);
   glVertex2f(0.60f,-0.1f);
   glVertex2f(0.60f,-0.2f);
   glVertex2f(0.60f,-0.3f);
   glVertex2f(0.60f,-0.4f);
   glVertex2f(0.60f,-0.5f);
   glVertex2f(0.60f,-0.6f);
   glVertex2f(0.60f,-0.7f);
   glVertex2f(0.60f,-0.8f);
   glVertex2f(0.60f,-0.9f);
   glVertex2f(0.60f,-1.0f);
   glVertex2f(0.70f,-0.1f);
   glVertex2f(0.70f,-0.2f);
   glVertex2f(0.70f,-0.3f);
   glVertex2f(0.70f,-0.4f);
   glVertex2f(0.70f,-0.5f);
   glVertex2f(0.70f,-0.6f);
   glVertex2f(0.70f,-0.7f);
   glVertex2f(0.70f,-0.8f);
   glVertex2f(0.70f,-0.9f);
   glVertex2f(0.70f,-1.0f);
   glVertex2f(0.80f,-0.1f);
   glVertex2f(0.80f,-0.2f);
   glVertex2f(0.80f,-0.3f);
   glVertex2f(0.80f,-0.4f);
   glVertex2f(0.80f,-0.5f);
   glVertex2f(0.80f,-0.6f);
   glVertex2f(0.80f,-0.7f);
   glVertex2f(0.80f,-0.8f);
   glVertex2f(0.80f,-0.9f);
   glVertex2f(0.80f,-1.0f);
   glVertex2f(0.90f,-0.1f);
   glVertex2f(0.90f,-0.2f);
   glVertex2f(0.90f,-0.3f);
   glVertex2f(0.90f,-0.4f);
   glVertex2f(0.90f,-0.5f);
   glVertex2f(0.90f,-0.6f);
   glVertex2f(0.90f,-0.7f);
   glVertex2f(0.90f,-0.8f);
   glVertex2f(0.90f,-0.9f);
   glVertex2f(0.90f,-1.0f);
   glEnd();

  glLoadIdentity();
  glPopMatrix();



   glFlush();
}


void handleKeypress(unsigned char key, int x, int y) {

	switch (key) {

case 'r':

glutDisplayFunc(display2);
glutPostRedisplay();
      
    break;
case 's':
glutDisplayFunc(display);
glutPostRedisplay();
    break;




	}
}


int main(int argc, char** argv) {
   glutInit(&argc, argv);
   glutInitWindowSize(320, 320);
   glutInitWindowPosition(50, 50);
   glutCreateWindow("Translation Animation");
   glutDisplayFunc(display);
 init();
//   glutSpecialFunc(SpecialInput);
   glutKeyboardFunc(handleKeypress);

   glutTimerFunc(100, Rain, 0);



   glutMainLoop();
   return 0;
}

