#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include<math.h>>
# define PI           3.14159265358979323846
GLfloat M = 0.0f;
GLfloat S =0.0f;
GLfloat H = 0.0f;


void display() {

    glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // Set background color to black and opaque
	glClear(GL_COLOR_BUFFER_BIT);
    GLfloat twicePi = 2.0f * PI;

	int triangleAmount = 50;
	GLfloat x=-.4f; GLfloat y=-.4f; GLfloat radius =.1f;
	int i;

	//clock


	x=0;y=0; radius=.8;
	//int triangleAmount = 20;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255,0,0);
    glVertex2f(x, y); // center of circle
    for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();


	//hours

    glBegin(GL_LINES);
    glColor3ub(0,0,0);
	glVertex2f(0,.6);
	glVertex2f(0,.8);
	glEnd();


	glBegin(GL_LINES);
    glColor3ub(0,0,0);
	glVertex2f(0,-.6);
	glVertex2f(0,-.8);
    glEnd();

	glBegin(GL_LINES);
    glColor3ub(0,0,0);
	glVertex2f(.6,0);
	glVertex2f(.8,0);
	glEnd();

	glBegin(GL_LINES);
    glColor3ub(0,0,0);
	glVertex2f(-.6,0);
	glVertex2f(-.8,0);
	glEnd();

    glBegin(GL_LINES);
    glColor3ub(0,0,0);
	glVertex2f(.75,.31);
	glVertex2f(.59,.29);
	glEnd();


	glBegin(GL_LINES);
    glColor3ub(0,0,0);
	glVertex2f(-.75,.31);
	glVertex2f(-.59,.29);
	glEnd();

	glBegin(GL_LINES);
    glColor3ub(0,0,0);
	glVertex2f(.69,-.49);
	glVertex2f(.59,-.39);
	glEnd();

	glBegin(GL_LINES);
    glColor3ub(0,0,0);
	glVertex2f(-.69,-.49);
	glVertex2f(-.59,-.39);
	glEnd();

	glBegin(GL_LINES);
    glColor3ub(0,0,0);
	glVertex2f(.49,.69);
	glVertex2f(.39,.59);
	glEnd();

	glBegin(GL_LINES);
    glColor3ub(0,0,0);
	glVertex2f(-.49,.69);
	glVertex2f(-.39,.59);
	glEnd();


    glBegin(GL_LINES);
    glColor3ub(0,0,0);
	glVertex2f(.49,-.69);
	glVertex2f(.39,-.59);
	glEnd();

    glBegin(GL_LINES);
    glColor3ub(0,0,0);
	glVertex2f(-.49,-.69);
	glVertex2f(-.39,-.59);
	glEnd();


    glPushMatrix();

    glRotatef(-S,0,0,1);

	//second hand
    glBegin(GL_LINES);
    glColor3ub(0,0,0);
	glVertex2f(0,0);
	glVertex2f(.4,.4);
	glEnd();

	glPopMatrix();

    glPushMatrix();
    glRotatef(-M,0,0,1);

    //minutes hand
    glBegin(GL_LINES);
    glColor3ub(0,0,0);
	glVertex2f(0,0);
	glVertex2f(.3,.3);
	glEnd();

	glPopMatrix();

    glPushMatrix();
    glRotatef(-H,0,0,1);

    //hour hand
    glBegin(GL_LINES);
    glColor3ub(0,0,0);
	glVertex2f(0,0);
	glVertex2f(.2,.2);
	glEnd();


	glPopMatrix();


	M+= 0.004;
	S+= 0.01;
	H+= 0.002;



	glFlush();  // Render now
}

void init()
{
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // Set background color to black and opaque
	glClear(GL_COLOR_BUFFER_BIT);
	//gluOrtho2D(-3,3,-3,3);
}


void idle()
{
    glutPostRedisplay();
}


//Main function: GLUT runs as a console application starting at main()
int main(int argc, char** argv) {
	glutInit(&argc, argv);                 // Initialize GLUT
	glutCreateWindow("Analog Clock"); // Create a window with the given title
	glutInitWindowSize(320, 320);   // Set the window's initial width & height
	glutDisplayFunc(display);// Register display callback handler for window re-paint
	glutIdleFunc(idle);

	glutMainLoop();           // Enter the event-processing loop
	return 0;
}
