#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include<math.h>>
# define PI           3.14159265358979323846
/* Handler for window-repaint event. Call back when the window first appears and
whenever the window needs to be re-painted. */

void display() {
	glClearColor(0.0f, 1.0f, 1.0f, 1.0f); // Set background color to black and opaque
	glClear(GL_COLOR_BUFFER_BIT);         // Clear the color buffer (background)
	int i;

	glLoadIdentity();

	glBegin(GL_QUADS);
	glColor3ub(255, 173, 51);
	glVertex2f(-1.0f, -1.0f);
	glVertex2f(1.0f, -1.0f);
	glVertex2f(1.0f, -0.3f);
	glVertex2f(-1.0f, -0.3f);// Sand
	glEnd();
	glBegin(GL_TRIANGLES);
	glColor3ub(153, 102, 51);
	glVertex2f(-0.1f, -0.3f);//bottom left
	glVertex2f(0.7f, -0.3f);//bottom right
	glVertex2f(0.5f, 0.5f);// top
	glEnd();//Pyramid 1 left side
	glBegin(GL_TRIANGLES);
	glColor3ub(102, 51, 0);
	glVertex2f(0.7f, -0.3f);//bottom left
	glVertex2f(1.0f, -0.3f);//bottom right
	glVertex2f(0.5f, 0.5f);// top
	glEnd();//Pyramid 1 right side
	glTranslatef(-0.6,-0.15,0);
	glScalef(0.5,0.5,0);
	glBegin(GL_TRIANGLES);
	glColor3ub(153, 102, 51);
	glVertex2f(-0.1f, -0.3f);//bottom left
	glVertex2f(0.7f, -0.3f);//bottom right
	glVertex2f(0.5f, 0.5f);// top
	glEnd();//Pyramid 2 left side
	glBegin(GL_TRIANGLES);
	glColor3ub(102, 51, 0);
	glVertex2f(0.7f, -0.3f);//bottom left
	glVertex2f(1.0f, -0.3f);//bottom right
	glVertex2f(0.5f, 0.5f);// top
	glEnd();//Pyramid 2 right side

    glLoadIdentity();
	glFlush();  // Render now
}

//Main Functions:
int main(int argc, char** argv) {
	glutInit(&argc, argv);                 // Initialize GLUT
	glutCreateWindow("OpenGL Setup Test"); // Create a window with the given title
	glutInitWindowSize(320, 320);   // Set the window's initial width & height
	glutDisplayFunc(display); // Register display callback handler for window re-paint
	glutMainLoop();           // Enter the event-processing loop
	return 0;
}
